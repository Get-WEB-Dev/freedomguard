# Testing

## Automated (runs in CI: `gradle :app:testDebugUnitTest`)
Marker matching per browser, uninstall-screen matching, PIN format rules, browser catalog and routes.

## Manual test plan (Galaxy M13, Android 14), record results in COMPATIBILITY.md
1. Fresh install > Setup: grant Accessibility (after "Allow restricted settings"), create PIN, activate device admin. Dashboard turns green.
2. Browsers > Teach private mode: capture a blank normal tab, then a blank private tab, then Learn. Then Security > Test mode ON. In each browser open a private tab. Activity log should show "Private mode detected". Check for false positives while using the browser normally. Test mode OFF.
3. Open a private tab again. The warning overlay must cover the screen. Both buttons must return to the home screen.
4. Tap "I tested it" on Browsers only for browsers that passed step 3.
5. PIN: wrong PIN 5 times > lockout message. Correct PIN > unlock.
6. Settings > Apps > Freedom Guard: PIN pad appears over it. Cancel > home. Correct PIN > 3-minute window.
7. Settings > Security > Device admin apps > Freedom Guard > Deactivate: PIN pad appears.
8. Uninstall from launcher with device admin active: Android refuses.
9. Restart the phone: status notification returns after unlock; Accessibility stays on; dashboard green.
10. Turn Accessibility off by hand: within ~15 s an alert notification appears and the dashboard turns red.
11. Revoke notification / usage access: app keeps running; dashboard counts fewer permissions; nothing crashes.
12. Android 14 background rules: the warning is an accessibility overlay (no activity launch), so nothing is blocked by background-activity-start limits. Confirm the watchdog starts after reboot (BOOT_COMPLETED) and when opening the app.
13. Warning customization: change text, pick an image, change theme; preview, then trigger a real warning.
14. Activity log > Clear log empties it.
