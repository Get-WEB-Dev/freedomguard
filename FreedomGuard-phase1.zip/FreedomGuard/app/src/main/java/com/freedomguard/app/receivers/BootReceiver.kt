package com.freedomguard.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.freedomguard.app.FreedomGuardApp
import com.freedomguard.app.services.WatchdogService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Restores the watchdog after reboot or app update. (Android restores enabled accessibility services itself.) */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val s = FreedomGuardApp.from(context).settings.flow.first()
                if (s.setupDone && s.protectionEnabled) WatchdogService.start(context)
            } finally {
                pending.finish()
            }
        }
    }
}
