package com.freedomguard.app.domain

/**
 * "Teach" mode: compare what a browser shows on a NORMAL page with what it shows on a PRIVATE page.
 * Whatever appears only in private is remembered as that browser's private-mode fingerprint on THIS phone.
 * Fingerprints are UI view ids and short UI labels, never page content.
 */
object Learning {
    const val SEP = '\u0001'
    private const val MAX_LABEL = 60
    private const val MAX_LEARNED = 60

    /** Fingerprint strings for one UI element. */
    fun signatures(viewId: String?, text: String?, desc: String?): List<String> {
        val out = ArrayList<String>(3)
        if (!viewId.isNullOrBlank()) out.add("id:$viewId")
        for (t in listOf(text, desc)) {
            val v = t?.trim()?.lowercase()
            if (!v.isNullOrEmpty() && v.length <= MAX_LABEL) out.add("txt:$v")
        }
        return out
    }

    /** Things seen only in the private capture. Labels with digits (counters, times) are dropped as noise. */
    fun diff(privateSigs: Set<String>, normalSigs: Set<String>): Set<String> =
        (privateSigs - normalSigs)
            .filter { !(it.startsWith("txt:") && it.any { c -> c.isDigit() }) }
            .sorted()
            .take(MAX_LEARNED)
            .toSet()

    fun encode(pkg: String, sig: String) = pkg + SEP + sig

    fun entriesFor(all: Set<String>, pkg: String): Set<String> {
        val prefix = pkg + SEP
        return all.filter { it.startsWith(prefix) }.map { it.removePrefix(prefix) }.toSet()
    }
}
