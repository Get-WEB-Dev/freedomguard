package com.freedomguard.app.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.freedomguard.app.ui.components.FgTopBar
import com.freedomguard.app.ui.components.Muted

private fun normalize(input: String): String {
    val t = input.trim()
    return when {
        t.startsWith("https://") -> t
        t.startsWith("http://") -> "https://" + t.removePrefix("http://")
        t.contains('.') && !t.contains(' ') -> "https://$t"
        else -> "https://duckduckgo.com/?q=" + Uri.encode(t)
    }
}

/** A deliberately plain browser: no private mode, no tabs, nothing hidden. HTTPS only. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SafeBrowserScreen(onBack: () -> Unit) {
    var address by remember { mutableStateOf("") }
    var webView by remember { mutableStateOf<WebView?>(null) }

    BackHandler {
        val w = webView
        if (w != null && w.canGoBack()) w.goBack() else onBack()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { FgTopBar("Safe Browser", onBack) },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = address, onValueChange = { address = it },
                    placeholder = { Text("Search or enter address") }, singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Button(onClick = { webView?.loadUrl(normalize(address)) }) { Text("Go") }
            }
            Muted("No private mode here. Freedom Guard does not record the pages you visit.")
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        webViewClient = WebViewClient()
                        webView = this
                    }
                },
                onRelease = { it.destroy() },
            )
        }
    }
}
