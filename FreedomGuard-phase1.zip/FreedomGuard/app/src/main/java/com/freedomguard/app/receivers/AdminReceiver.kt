package com.freedomguard.app.receivers

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import com.freedomguard.app.FreedomGuardApp
import com.freedomguard.app.data.EventKind
import com.freedomguard.app.data.ProtectionEvent

/** Device-admin hook. Holds no policies; its only purpose is to make Android block uninstall while active. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        log(context, EventKind.ADMIN_DISABLE_REQUESTED, "Deactivation screen reached")
        return "Deactivating removes Freedom Guard's uninstall protection. Remember the commitment you made to yourself."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        log(context, EventKind.ADMIN_DISABLED, "Device admin was deactivated")
    }

    private fun log(ctx: Context, kind: String, detail: String) {
        try {
            FreedomGuardApp.from(ctx).events.append(ProtectionEvent(System.currentTimeMillis(), kind, "", detail))
        } catch (e: Exception) {
            // logging must never crash the receiver
        }
    }
}
