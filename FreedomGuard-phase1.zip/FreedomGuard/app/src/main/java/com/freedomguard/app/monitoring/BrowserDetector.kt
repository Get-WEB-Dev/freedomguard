package com.freedomguard.app.monitoring

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.freedomguard.app.domain.BrowserDef
import com.freedomguard.app.domain.KnownBrowsers

data class InstalledBrowser(val def: BrowserDef, val installed: Boolean, val versionName: String?)

@Suppress("DEPRECATION")
class BrowserDetector(private val pm: PackageManager, private val ownPackage: String) {

    fun scan(): List<InstalledBrowser> = KnownBrowsers.all.map { def ->
        val info = try {
            pm.getPackageInfo(def.packageName, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
        InstalledBrowser(def, info != null, info?.versionName)
    }

    /** Browsers installed on the phone that Freedom Guard does NOT support (their private mode is not blocked). */
    fun unsupportedBrowsers(): List<String> {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE)
        val known = KnownBrowsers.all.map { it.packageName }.toSet()
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first !in known && it.first != ownPackage }
            .distinctBy { it.first }
            .map { it.second }
    }
}
