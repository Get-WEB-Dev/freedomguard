package com.freedomguard.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.freedomguard.app.domain.DEFAULT_WARNING_TEXT
import com.freedomguard.app.domain.KnownBrowsers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.fgStore by preferencesDataStore(name = "freedom_guard_settings")

data class SettingsData(
    val loaded: Boolean = false,
    val setupDone: Boolean = false,
    val protectionEnabled: Boolean = true,
    val logOnly: Boolean = false,
    val warningText: String = DEFAULT_WARNING_TEXT,
    val theme: String = "Navy",
    val monitoredBrowsers: Set<String> = KnownBrowsers.all.map { it.packageName }.toSet(),
    val verifiedBrowsers: Set<String> = emptySet(),
    val removalDelayHours: Int = 0,
    val removalRequestedAt: Long = 0L,
    val removalOpenUntil: Long = 0L,
    val imageVersion: Long = 0L,
)

object SettingsKeys {
    val setupDone = booleanPreferencesKey("setup_done")
    val protection = booleanPreferencesKey("protection_enabled")
    val logOnly = booleanPreferencesKey("log_only")
    val text = stringPreferencesKey("warning_text")
    val theme = stringPreferencesKey("theme")
    val monitored = stringSetPreferencesKey("monitored")
    val verified = stringSetPreferencesKey("verified")
    val delay = intPreferencesKey("removal_delay_hours")
    val requestedAt = longPreferencesKey("removal_requested_at")
    val openUntil = longPreferencesKey("removal_open_until")
    val imageVersion = longPreferencesKey("image_version")
}

class SettingsRepository(private val context: Context) {
    private val defaults = SettingsData()

    val flow: Flow<SettingsData> = context.fgStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            SettingsData(
                loaded = true,
                setupDone = p[SettingsKeys.setupDone] ?: false,
                protectionEnabled = p[SettingsKeys.protection] ?: true,
                logOnly = p[SettingsKeys.logOnly] ?: false,
                warningText = p[SettingsKeys.text] ?: DEFAULT_WARNING_TEXT,
                theme = p[SettingsKeys.theme] ?: "Navy",
                monitoredBrowsers = p[SettingsKeys.monitored] ?: defaults.monitoredBrowsers,
                verifiedBrowsers = p[SettingsKeys.verified] ?: emptySet(),
                removalDelayHours = p[SettingsKeys.delay] ?: 0,
                removalRequestedAt = p[SettingsKeys.requestedAt] ?: 0L,
                removalOpenUntil = p[SettingsKeys.openUntil] ?: 0L,
                imageVersion = p[SettingsKeys.imageVersion] ?: 0L,
            )
        }

    suspend fun edit(block: (MutablePreferences) -> Unit) {
        context.fgStore.edit { block(it) }
    }
}
