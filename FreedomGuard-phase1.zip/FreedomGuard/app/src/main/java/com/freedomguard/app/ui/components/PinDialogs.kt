package com.freedomguard.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.freedomguard.app.ui.theme.Red500

/** Holds "ask for PIN, then run this" state. [action] gets the PIN and must call done(null) on success. */
class PinGate {
    var title by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
    private var action: ((String, (String?) -> Unit) -> Unit)? = null

    fun request(title: String, action: (pin: String, done: (String?) -> Unit) -> Unit) {
        error = null
        this.action = action
        this.title = title
    }

    fun submit(pin: String) {
        action?.invoke(pin) { err -> if (err == null) close() else error = err }
    }

    fun close() {
        title = null
        error = null
        action = null
    }
}

@Composable
fun rememberPinGate(): PinGate = remember { PinGate() }

@Composable
fun PinField(value: String, label: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 8 && it.all { c -> c.isDigit() }) onChange(it) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
fun PinGateDialog(gate: PinGate) {
    val title = gate.title ?: return
    var pin by remember(title) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { gate.close() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PinField(pin, "PIN") { pin = it }
                gate.error?.let { Text(it, color = Red500, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = { TextButton(onClick = { gate.submit(pin) }) { Text("Confirm") } },
        dismissButton = { TextButton(onClick = { gate.close() }) { Text("Cancel") } },
    )
}

/** Create a PIN (askOld = false) or change it (askOld = true). */
@Composable
fun PinSetupDialog(
    askOld: Boolean,
    onSubmit: (old: String, new: String, confirm: String, done: (String?) -> Unit) -> Unit,
    onClose: () -> Unit,
) {
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (askOld) "Change PIN" else "Create a PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (askOld) PinField(old, "Current PIN") { old = it }
                PinField(new, "New PIN (4–8 digits)") { new = it }
                PinField(confirm, "Repeat new PIN") { confirm = it }
                error?.let { Text(it, color = Red500, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSubmit(old, new, confirm) { err -> if (err == null) onClose() else error = err } }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )
}
