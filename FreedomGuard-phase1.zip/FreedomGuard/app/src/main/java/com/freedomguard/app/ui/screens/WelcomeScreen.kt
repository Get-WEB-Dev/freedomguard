package com.freedomguard.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.Navy900
import com.freedomguard.app.ui.theme.TextPrimary
import com.freedomguard.app.ui.theme.TextSecondary

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Navy900)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        ShieldIllustration(Modifier.size(200.dp))
        Text("Freedom Guard", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(
            "A personal self-control tool that helps you stay on track when you browse.",
            textAlign = TextAlign.Center,
            color = TextSecondary,
            style = MaterialTheme.typography.bodyLarge,
        )
        FgCard {
            Heading("What you should know")
            Muted("• Everything stays on your phone. No account, no cloud, and the app has no internet permission.")
            Muted("• It never reads your browsing history, pages or passwords.")
            Muted("• Android does not let ordinary apps switch off every browser's private mode. Freedom Guard will always tell you exactly which browsers are protected and which are not.")
        }
        Spacer(Modifier.height(8.dp))
        BigButton("Get started", onStart)
    }
}
