package com.freedomguard.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.TextPrimary
import com.freedomguard.app.ui.theme.TextSecondary

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Spacer(Modifier.height(16.dp))
        ShieldIllustration(Modifier.size(180.dp))
        Text("Freedom Guard", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(
            "A personal self-control tool that helps you stay on track when you browse.",
            textAlign = TextAlign.Center, color = TextSecondary, style = MaterialTheme.typography.bodyLarge,
        )
        FgCard {
            Heading("What you should know")
            Muted("• Everything stays on your phone. No account, no cloud. The only internet use is the optional built-in Safe Browser.")
            Muted("• It never stores what it sees on screen, and it never reads web pages, URLs or passwords.")
            Muted("• Android doesn't let ordinary apps switch off private mode. Freedom Guard spots private-mode screens and covers them with a warning. This is experimental and only works in the browsers listed in the app.")
            Muted("• It makes removal hard (PIN lock, device admin, optional delay), but cannot make it impossible.")
        }
        BigButton("Get started", onStart)
    }
}
