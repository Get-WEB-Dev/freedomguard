package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.freedomguard.app.domain.Learning
import com.freedomguard.app.monitoring.CaptureController
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.UiState
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun TeachScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit) {
    val installed = state.browsers.filter { it.installed }
    var pkg by remember { mutableStateOf(installed.firstOrNull()?.def?.packageName) }
    var message by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) { while (true) { delay(500); tick = System.currentTimeMillis() } }

    val current = installed.firstOrNull { it.def.packageName == pkg }
    val learnedCount = pkg?.let { Learning.entriesFor(state.settings.learned, it).size } ?: 0

    FgScreen(title = "Teach private mode", onBack = onBack) {
        Muted("Freedom Guard compares a normal page with a private page in the same browser, and remembers what only appears in private. Nothing about web pages is read. Use BLANK new tabs only, so no page titles are on screen.")

        if (installed.isEmpty()) {
            FgCard { Muted("No supported browser is installed.") }
            return@FgScreen
        }

        FgCard {
            Heading("Browser")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                installed.take(3).forEach { b ->
                    FilterChip(selected = pkg == b.def.packageName, onClick = { pkg = b.def.packageName; message = null }, label = { Text(b.def.name.removePrefix("Google ").removePrefix("Mozilla ").removePrefix("Microsoft ")) })
                }
            }
            if (installed.size > 3) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                installed.drop(3).forEach { b ->
                    FilterChip(selected = pkg == b.def.packageName, onClick = { pkg = b.def.packageName; message = null }, label = { Text(b.def.name.removePrefix("Google ").removePrefix("Mozilla ").removePrefix("Microsoft ")) })
                }
            }
        }

        val p = pkg ?: return@FgScreen
        val name = current?.def?.name ?: "the browser"

        CaptureStep(
            title = "1. Capture a NORMAL page",
            how = "Tap Start, then open $name within a few seconds and stay on a blank NEW normal tab (not private) until the timer ends.",
            pkg = p, kind = "normal", tick = tick, onStart = { vm.startCapture(p, "normal"); message = null },
        )
        CaptureStep(
            title = "2. Capture a PRIVATE page",
            how = "Tap Start, then open $name, switch to a blank PRIVATE tab (Incognito / Secret / InPrivate) and stay there until the timer ends. Do this yourself; Freedom Guard is only watching, not blocking, while capturing.",
            pkg = p, kind = "private", tick = tick, onStart = { vm.startCapture(p, "private"); message = null },
        )

        FgCard {
            Heading("3. Learn")
            BigButton("Learn the difference", { message = vm.learnFrom(p) ?: "Learned. Private screens in $name are now blocked." })
            message?.let { Text(it, color = if (it.startsWith("Learned")) Green500 else Orange500) }
            if (learnedCount > 0) {
                StatusChip("$learnedCount fingerprints stored for $name", Green500)
                BigButton("Forget what was learned", { vm.clearLearned(p); message = null }, outlined = true)
            }
        }
        Muted("Tip: test it. With protection on, switch to a private tab in $name; the warning should appear. If a NORMAL page ever triggers the warning, tap “Forget what was learned” and redo Step 1 on a different normal page.")
    }
}

@Composable
private fun CaptureStep(title: String, how: String, pkg: String, kind: String, tick: Long, onStart: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val refresh = tick // changes twice a second so the timer redraws
    val left = CaptureController.secondsLeft(pkg, kind)
    val got = CaptureController.result(pkg, kind)?.size ?: 0
    FgCard {
        Heading(title)
        Muted(how)
        when {
            left > 0 -> StatusChip("Capturing… ${left}s left (captured $got items)", Orange500)
            got > 0 -> StatusChip("Captured $got items", Green500)
        }
        BigButton(if (got > 0 && left == 0L) "Capture again" else "Start 20-second capture", onStart, enabled = left == 0L, outlined = got > 0)
    }
}
