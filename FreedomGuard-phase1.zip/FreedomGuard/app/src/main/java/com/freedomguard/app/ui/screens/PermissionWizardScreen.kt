package com.freedomguard.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.TextSecondary

private data class WizardStep(val title: String, val why: String, val required: Boolean)

private val steps = listOf(
    WizardStep(
        "Usage access",
        "Lets Freedom Guard see which app is in the foreground (for example, that a browser is open). It does not show what you do inside the browser.",
        required = true,
    ),
    WizardStep(
        "Notifications",
        "Android 13+ requires your permission to show the 'protection is running' notification and warning alerts.",
        required = true,
    ),
    WizardStep(
        "Show warning over other apps",
        "Optional. Allows the warning screen to appear on top of a browser. Without it, the warning can only appear via a notification or when you open Freedom Guard.",
        required = false,
    ),
    WizardStep(
        "Battery: unrestricted",
        "Optional but recommended on Samsung phones, which stop background apps aggressively. Without it, monitoring may be paused by the system.",
        required = false,
    ),
)

@Composable
fun PermissionWizardScreen(onBack: () -> Unit, onFinish: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    val step = steps[index]

    FgScreen(title = "Permission setup", onBack = onBack) {
        LinearProgressIndicator(progress = { (index + 1) / steps.size.toFloat() }, modifier = Modifier.fillMaxWidth())
        Text("Step ${index + 1} of ${steps.size}", color = TextSecondary)

        AnimatedContent(targetState = step, label = "wizardStep") { s ->
            FgCard {
                CenteredColumn { ShieldIllustration(Modifier.size(96.dp)) }
                Heading(s.title + if (s.required) "" else " (optional)")
                Muted(s.why)
            }
        }
        PhaseNotice("Granting and checking this permission is added in Phase 2. In this build the wizard is a visual walkthrough only.")

        BigButton("Grant permission (Phase 2)", onClick = {}, enabled = false)
        if (index < steps.lastIndex) {
            BigButton("Next", onClick = { index++ }, outlined = true)
        } else {
            BigButton("Finish", onFinish)
        }
    }
}
