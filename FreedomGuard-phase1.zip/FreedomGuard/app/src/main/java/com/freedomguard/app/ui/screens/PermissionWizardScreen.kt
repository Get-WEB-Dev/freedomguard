package com.freedomguard.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.freedomguard.app.permissions.SettingsIntents
import com.freedomguard.app.permissions.safeStart
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.UiState
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.*

@Composable
private fun StepCard(
    title: String,
    done: Boolean?,
    required: Boolean,
    body: String,
    button: String?,
    onClick: () -> Unit = {},
) {
    FgCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f))
            when {
                done == true -> StatusChip("Done", Green500)
                required -> StatusChip("Required", Orange500)
                else -> StatusChip("Optional", TextSecondary)
            }
        }
        Muted(body)
        if (button != null && done != true) BigButton(button, onClick, outlined = true)
    }
}

@Composable
fun PermissionWizardScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit, onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val p = state.permissions
    var showPin by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refresh() }

    FgScreen(title = "Setup", onBack = onBack) {
        Muted("Work through these steps. Only the first four matter for protection; the rest improve reliability.")

        StepCard(
            "1. Allow restricted settings", null, false,
            "Because this app was installed from a file, Android 13+ may grey out the Accessibility switch. If so: open App info → tap ⋮ (top right) → “Allow restricted settings”, then continue. If you don't see ⋮, skip this step.",
            "Open App info",
        ) { ctx.safeStart(SettingsIntents.appDetails(ctx)) }

        StepCard(
            "2. Accessibility service", p.accessibility, true,
            "This is what detects private-mode screens and shows the warning. Freedom Guard reads only on-screen button labels in the supported browsers. It ignores web page content and text fields and stores nothing it reads. Find “Freedom Guard” under Installed apps and switch it on.",
            "Open Accessibility settings",
        ) { ctx.safeStart(SettingsIntents.accessibility()) }

        StepCard(
            "3. Create a PIN", state.hasPin, true,
            "The PIN protects the app's settings and the uninstall / disable screens. It is stored as a salted hash, encrypted with a key held in the Android Keystore. Choose something you won't share, and don't forget it: there is no recovery.",
            "Create PIN",
        ) { showPin = true }

        StepCard(
            "4. Device admin (uninstall protection)", p.deviceAdmin, true,
            "While this is active, Android refuses to uninstall Freedom Guard. Freedom Guard asks for no other admin powers: it cannot lock, wipe or monitor your phone.",
            "Activate device admin",
        ) { ctx.safeStart(SettingsIntents.deviceAdmin(ctx)) }

        StepCard(
            "5. Usage access", p.usageAccess, false,
            "Lets the watchdog see which app is in front so it can log if a browser is used while protection is off. It only sees app names, never content.",
            "Open Usage access",
        ) { ctx.safeStart(SettingsIntents.usageAccess()) }

        StepCard(
            "6. Notifications", p.notifications, false,
            "Needed for the “protection is running” notice and for alerts if protection gets switched off.",
            "Allow notifications",
        ) {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            else ctx.safeStart(SettingsIntents.appDetails(ctx))
        }

        StepCard(
            "7. Battery: unrestricted", p.batteryUnrestricted, false,
            "Samsung phones stop background apps aggressively. Setting Freedom Guard to “Unrestricted” keeps the watchdog alive. In the list choose “All apps”, find Freedom Guard and select Don't optimize.",
            "Open battery settings",
        ) { ctx.safeStart(SettingsIntents.battery()) }

        BigButton("Finish setup", onFinish, enabled = p.accessibility && state.hasPin)
        if (!(p.accessibility && state.hasPin)) Muted("Finish unlocks once steps 2 and 3 are done.")
    }

    if (showPin) {
        PinSetupDialog(
            askOld = false,
            onSubmit = { _, new, confirm, done -> vm.setInitialPin(new, confirm, done) },
            onClose = { showPin = false },
        )
    }
}
