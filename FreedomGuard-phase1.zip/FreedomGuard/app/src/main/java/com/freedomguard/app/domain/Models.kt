package com.freedomguard.app.domain

/** A browser Freedom Guard knows about. Detection (is it installed?) arrives in Phase 2. */
data class KnownBrowser(val name: String, val packageName: String)

object KnownBrowsers {
    val all = listOf(
        KnownBrowser("Google Chrome", "com.android.chrome"),
        KnownBrowser("Samsung Internet", "com.sec.android.app.sbrowser"),
        KnownBrowser("Mozilla Firefox", "org.mozilla.firefox"),
        KnownBrowser("Opera", "com.opera.browser"),
        KnownBrowser("Microsoft Edge", "com.microsoft.emmx"),
        KnownBrowser("Brave", "com.brave.browser"),
    )
}

const val DEFAULT_WARNING_TEXT =
    "STOP!\n\nRemember the commitment you made to yourself.\n\n" +
        "Do not sacrifice your future for a temporary moment.\n\n" +
        "Stay focused. Stay disciplined. Choose your goals."
