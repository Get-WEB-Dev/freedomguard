package com.freedomguard.app.domain

/**
 * A supported browser. Two kinds of lowercase English labels are used (heuristics, can break on UI updates):
 *  - [entryPhrases]: text of the control that OPENS private mode. Matched (contains) only when that control is TAPPED.
 *  - [insideExact] / [insidePrefixes]: labels shown inside an already-open private window. Matched strictly
 *    (whole label equals, or label starts with) so menus and settings that merely mention the word do not trigger.
 */
data class BrowserDef(
    val name: String,
    val packageName: String,
    val privateLabel: String,
    val entryPhrases: List<String>,
    val insideExact: List<String>,
    val insidePrefixes: List<String> = emptyList(),
)

object KnownBrowsers {
    val all = listOf(
        BrowserDef("Google Chrome", "com.android.chrome", "Incognito",
            listOf("new incognito tab"), listOf("incognito"), listOf("you've gone incognito")),
        BrowserDef("Samsung Internet", "com.sec.android.app.sbrowser", "Secret mode",
            listOf("turn on secret mode", "new secret tab"), listOf("secret mode"), listOf("secret mode is")),
        BrowserDef("Mozilla Firefox", "org.mozilla.firefox", "Private browsing",
            listOf("new private tab", "open a new private tab"), listOf("private browsing")),
        BrowserDef("Opera", "com.opera.browser", "Private mode",
            listOf("new private tab", "private mode"), listOf("private mode")),
        BrowserDef("Microsoft Edge", "com.microsoft.emmx", "InPrivate",
            listOf("new inprivate tab", "new inprivate window"), listOf("inprivate")),
        BrowserDef("Brave", "com.brave.browser", "Private window",
            listOf("new private tab", "new private window"), listOf("private tab", "private")),
    )

    fun byPackage(pkg: String): BrowserDef? = all.firstOrNull { it.packageName == pkg }
}

/** System screens where uninstalling / force-stopping / deactivating Freedom Guard can happen. */
object TamperPackages {
    val all = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller",
    )
}

val THEME_CHOICES = listOf("Navy", "Midnight", "AMOLED")

const val DEFAULT_WARNING_TEXT =
    "STOP!\n\nRemember the commitment you made to yourself.\n\n" +
        "Do not sacrifice your future for a temporary moment.\n\n" +
        "Stay focused. Stay disciplined. Choose your goals."
