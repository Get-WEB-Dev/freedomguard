package com.freedomguard.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.freedomguard.app.ui.theme.*

/** Shield-with-lock illustration drawn in code so it needs no image assets. */
@Composable
fun ShieldIllustration(modifier: Modifier = Modifier.size(160.dp), top: Color = Blue400, bottom: Color = Blue700) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val shield = Path().apply {
            moveTo(w * 0.5f, h * 0.04f)
            lineTo(w * 0.9f, h * 0.18f)
            lineTo(w * 0.9f, h * 0.5f)
            cubicTo(w * 0.9f, h * 0.75f, w * 0.7f, h * 0.92f, w * 0.5f, h * 0.98f)
            cubicTo(w * 0.3f, h * 0.92f, w * 0.1f, h * 0.75f, w * 0.1f, h * 0.5f)
            lineTo(w * 0.1f, h * 0.18f)
            close()
        }
        drawPath(shield, brush = Brush.verticalGradient(listOf(top, bottom)))
        drawPath(shield, color = Color.White.copy(alpha = 0.25f), style = Stroke(width = w * 0.02f))
        drawArc(
            Color.White, startAngle = 180f, sweepAngle = 180f, useCenter = false,
            topLeft = Offset(w * 0.40f, h * 0.30f), size = Size(w * 0.20f, h * 0.34f),
            style = Stroke(width = w * 0.045f, cap = StrokeCap.Round),
        )
        drawRoundRect(
            Color.White, topLeft = Offset(w * 0.34f, h * 0.47f),
            size = Size(w * 0.32f, h * 0.26f), cornerRadius = CornerRadius(w * 0.04f),
        )
        drawCircle(bottom, radius = w * 0.028f, center = Offset(w * 0.5f, h * 0.57f))
    }
}

/** Standard screen frame: navy background, optional back arrow, scrollable padded column. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FgScreen(
    title: String,
    onBack: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = TextPrimary,
                    navigationIconContentColor = TextPrimary,
                ),
            )
        },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content,
        )
    }
}

@Composable
fun FgCard(modifier: Modifier = Modifier, accent: Color? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Navy800),
    ) {
        Column(
            Modifier
                .then(if (accent != null) Modifier.background(accent.copy(alpha = 0.10f)) else Modifier)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content,
        )
    }
}

@Composable
fun StatusDot(color: Color) {
    Box(Modifier.size(12.dp).background(color, CircleShape))
}

@Composable
fun BigButton(text: String, onClick: () -> Unit, enabled: Boolean = true, outlined: Boolean = false) {
    val mod = Modifier.fillMaxWidth().height(54.dp)
    if (outlined) {
        OutlinedButton(onClick, mod, enabled = enabled, shape = RoundedCornerShape(16.dp)) { Text(text) }
    } else {
        Button(onClick, mod, enabled = enabled, shape = RoundedCornerShape(16.dp)) { Text(text, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
fun Muted(text: String) = Text(text, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)

@Composable
fun Heading(text: String) = Text(text, color = TextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

@Composable
fun PhaseNotice(text: String) = FgCard(accent = Orange500) {
    Text("Not implemented yet", color = Orange500, fontWeight = FontWeight.SemiBold)
    Muted(text)
}

@Composable
fun CenteredColumn(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, content = content)
