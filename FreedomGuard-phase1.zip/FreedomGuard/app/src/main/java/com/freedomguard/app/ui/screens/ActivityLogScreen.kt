package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.UiState
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.TextPrimary

@Composable
fun ActivityLogScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit) {
    FgScreen(title = "Activity log", onBack = onBack) {
        Muted("Stored only on this phone: time, event type, browser name and a short note. Never URLs, page content or anything you typed.")
        if (state.events.isEmpty()) {
            FgCard {
                CenteredColumn { ShieldIllustration(Modifier.size(96.dp)) }
                Heading("No events yet")
            }
        } else {
            state.events.take(200).forEach { e ->
                FgCard {
                    Text(describe(e), fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Muted(formatTime(e.time) + if (e.detail.isNotBlank() && !e.kind.startsWith("REMOVAL")) " · ${e.detail}" else "")
                }
            }
            BigButton("Clear log", { vm.clearLog() }, outlined = true)
        }
    }
}
