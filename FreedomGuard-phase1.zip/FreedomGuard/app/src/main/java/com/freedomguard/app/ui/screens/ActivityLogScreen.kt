package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.freedomguard.app.ui.components.*

@Composable
fun ActivityLogScreen(onBack: () -> Unit) {
    FgScreen(title = "Activity log", onBack = onBack) {
        FgCard {
            CenteredColumn { ShieldIllustration(Modifier.size(96.dp)) }
            Heading("No events yet")
            Muted("Only protection events (time, browser, and what was detected) will be stored, locally on this phone. No URLs or page content are ever recorded.")
        }
        BigButton("Clear log (Phase 5)", {}, enabled = false, outlined = true)
    }
}
