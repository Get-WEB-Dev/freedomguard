package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.*

@Composable
fun DashboardScreen(
    onBrowsers: () -> Unit,
    onCustomize: () -> Unit,
    onSecurity: () -> Unit,
    onLog: () -> Unit,
    onWizard: () -> Unit,
    onPreviewWarning: () -> Unit,
) {
    FgScreen(title = "Freedom Guard") {
        // Phase 1: nothing is monitored yet, so we must NOT show a green "active" state.
        FgCard(accent = Orange500) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ShieldIllustration(Modifier.size(72.dp), top = Orange500, bottom = Navy900)
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusDot(Orange500)
                        Text("Protection not active", fontWeight = FontWeight.Bold, color = Orange500)
                    }
                    Muted("Setup is incomplete and monitoring is not implemented in this build.")
                }
            }
            BigButton("Open setup wizard", onWizard)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Browsers detected", "–", "Phase 2", Modifier.weight(1f))
            StatCard("Permissions", "–", "Not checked", Modifier.weight(1f))
        }
        FgCard {
            Heading("Last protection event")
            Muted("No events recorded.")
        }

        Heading("Manage")
        NavRow("Browsers", "Choose which browsers to monitor", onBrowsers)
        NavRow("Customize warning", "Text, image and theme", onCustomize)
        NavRow("Security", "PIN and safeguards", onSecurity)
        NavRow("Activity log", "Local protection events", onLog)
        BigButton("Preview warning screen", onPreviewWarning, outlined = true)
        Spacer(Modifier.height(16.dp))
    }
}


@Composable
private fun StatCard(label: String, value: String, note: String, modifier: Modifier) {
    FgCard(modifier) {
        Muted(label)
        Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(note, color = Orange500, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun NavRow(title: String, subtitle: String, onClick: () -> Unit) {
    androidx.compose.material3.Card(
        onClick = onClick,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Navy800),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Muted(subtitle)
        }
    }
}
