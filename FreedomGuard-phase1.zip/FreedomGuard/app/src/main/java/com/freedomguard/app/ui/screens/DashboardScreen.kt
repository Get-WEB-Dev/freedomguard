package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.freedomguard.app.ui.Level
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.UiState
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.healthOf
import com.freedomguard.app.ui.navigation.Routes
import com.freedomguard.app.ui.theme.*

@Composable
fun DashboardScreen(vm: MainViewModel, state: UiState, nav: (String) -> Unit) {
    val gate = rememberPinGate()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    val health = healthOf(state)
    val color: Color = when (health.level) {
        Level.OK -> Green500
        Level.WARN -> Orange500
        Level.BAD -> Red500
    }

    fun go(route: String) {
        if (vm.isUnlocked()) nav(route) else gate.request("Enter PIN to continue") { pin, done ->
            vm.unlock(pin) { err -> done(err); if (err == null) nav(route) }
        }
    }

    FgScreen(title = "Freedom Guard") {
        FgCard(accent = color) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ShieldIllustration(Modifier.size(72.dp), top = color, bottom = MaterialTheme.colorScheme.background)
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusDot(color)
                        Text(health.title, fontWeight = FontWeight.Bold, color = color)
                    }
                    Muted(health.detail)
                }
            }
            if (!state.settings.setupDone || !state.permissions.accessibility) BigButton("Open setup", { nav(Routes.WIZARD) })
            if (state.settings.setupDone && !state.settings.protectionEnabled) BigButton("Turn protection back on", { vm.enableProtection() })
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Browsers detected", "${state.installedCount}/${state.browsers.size}", if (state.installedCount > 0) Green500 else Orange500, Modifier.weight(1f))
            StatCard("Permissions", "${state.permissions.grantedCount}/${state.permissions.totalCount}", if (state.permissions.accessibility) Green500 else Red500, Modifier.weight(1f))
        }

        FgCard {
            Heading("Last protection event")
            val last = state.events.firstOrNull()
            if (last == null) Muted("No events recorded.") else {
                Text(describe(last), color = TextPrimary)
                Muted(formatTime(last.time))
            }
        }

        if (state.unsupportedBrowsers.isNotEmpty()) {
            FgCard(accent = Orange500) {
                Text("Unprotected browsers installed", color = Orange500, fontWeight = FontWeight.SemiBold)
                Muted("Freedom Guard cannot block private mode in: ${state.unsupportedBrowsers.joinToString(", ")}.")
            }
        }

        Heading("Manage")
        NavRow("Browsers", "Which browsers are watched, and how well", { go(Routes.BROWSERS) })
        NavRow("Customize warning", "Text, image and theme", { go(Routes.CUSTOMIZE) })
        NavRow("Security", "PIN, removal delay, test mode", { go(Routes.SECURITY) })
        NavRow("Activity log", "Local protection events", { go(Routes.LOG) })
        NavRow("Safe Browser", "A simple browser with no private mode", { nav(Routes.SAFE) })
        BigButton("Preview warning screen", { nav(Routes.WARNING) }, outlined = true)
        Spacer(Modifier.height(16.dp))
    }
    PinGateDialog(gate)
}

@Composable
private fun StatCard(label: String, value: String, color: Color, modifier: Modifier) {
    FgCard(modifier) {
        Muted(label)
        Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun NavRow(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Muted(subtitle)
        }
    }
}
