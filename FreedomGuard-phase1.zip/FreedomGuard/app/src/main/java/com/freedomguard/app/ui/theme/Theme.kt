package com.freedomguard.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Blue400 = Color(0xFF60A5FA)
val Blue500 = Color(0xFF3B82F6)
val Blue700 = Color(0xFF1D4ED8)
val Green500 = Color(0xFF22C55E)
val Orange500 = Color(0xFFF59E0B)
val Red500 = Color(0xFFEF4444)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)

private fun scheme(bg: Long, surface: Long, variant: Long): ColorScheme = darkColorScheme(
    primary = Blue500,
    onPrimary = Color.White,
    secondary = Blue400,
    background = Color(bg),
    onBackground = TextPrimary,
    surface = Color(surface),
    onSurface = TextPrimary,
    surfaceVariant = Color(variant),
    onSurfaceVariant = TextSecondary,
    error = Red500,
)

fun schemeFor(name: String): ColorScheme = when (name) {
    "Midnight" -> scheme(0xFF070B1F, 0xFF0E1430, 0xFF18204A)
    "AMOLED" -> scheme(0xFF000000, 0xFF0B0B0F, 0xFF16161D)
    else -> scheme(0xFF0A1330, 0xFF111C40, 0xFF1A2858)
}

private val FgShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
)

@Composable
fun FreedomGuardTheme(theme: String, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = schemeFor(theme), shapes = FgShapes, content = content)
}
