package com.freedomguard.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Navy900 = Color(0xFF0A1330)
val Navy800 = Color(0xFF111C40)
val Navy700 = Color(0xFF1A2858)
val Blue400 = Color(0xFF60A5FA)
val Blue500 = Color(0xFF3B82F6)
val Blue700 = Color(0xFF1D4ED8)
val Green500 = Color(0xFF22C55E)
val Orange500 = Color(0xFFF59E0B)
val Red500 = Color(0xFFEF4444)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)

private val FgColors = darkColorScheme(
    primary = Blue500,
    onPrimary = Color.White,
    secondary = Blue400,
    background = Navy900,
    onBackground = TextPrimary,
    surface = Navy800,
    onSurface = TextPrimary,
    surfaceVariant = Navy700,
    onSurfaceVariant = TextSecondary,
    error = Red500,
)

private val FgShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
)

@Composable
fun FreedomGuardTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = FgColors, shapes = FgShapes, content = content)
}
