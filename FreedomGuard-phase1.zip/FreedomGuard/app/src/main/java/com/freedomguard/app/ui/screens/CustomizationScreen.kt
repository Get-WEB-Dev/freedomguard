package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.freedomguard.app.domain.DEFAULT_WARNING_TEXT
import com.freedomguard.app.ui.components.*

@Composable
fun CustomizationScreen(onBack: () -> Unit, onPreview: () -> Unit) {
    var text by remember { mutableStateOf(DEFAULT_WARNING_TEXT) }
    var theme by remember { mutableStateOf("Navy") }

    FgScreen(title = "Customize", onBack = onBack) {
        FgCard {
            Heading("Warning text")
            OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 6)
            BigButton("Reset to default", { text = DEFAULT_WARNING_TEXT }, outlined = true)
        }
        FgCard {
            Heading("Warning image")
            Muted("Pick a personal photo to show on the warning screen.")
            BigButton("Choose image (Phase 4)", {}, enabled = false)
        }
        FgCard {
            Heading("Theme")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Navy", "Midnight", "AMOLED").forEach { t ->
                    FilterChip(selected = theme == t, onClick = { theme = t }, label = { androidx.compose.material3.Text(t) })
                }
            }
            Muted("Theme switching is wired up in a later phase; this selector does not change colors yet.")
        }
        PhaseNotice("Text edits here are not saved yet. Saving (DataStore) and applying them to the real warning screen arrive in Phase 4.")
        BigButton("Preview warning screen", onPreview)
    }
}
