package com.freedomguard.app.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.freedomguard.app.data.WarningImageStore
import com.freedomguard.app.domain.DEFAULT_WARNING_TEXT
import com.freedomguard.app.domain.THEME_CHOICES
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.UiState
import com.freedomguard.app.ui.components.*

@Composable
fun CustomizationScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit, onPreview: () -> Unit) {
    val ctx = LocalContext.current
    val s = state.settings
    var text by remember(s.warningText) { mutableStateOf(s.warningText) }
    val image = remember(s.imageVersion) { WarningImageStore.load(ctx) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setWarningImage(uri) { ok ->
            Toast.makeText(ctx, if (ok) "Image saved" else "Could not use that image", Toast.LENGTH_SHORT).show()
        }
    }

    FgScreen(title = "Customize", onBack = onBack) {
        FgCard {
            Heading("Warning text")
            OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 6)
            BigButton("Save text", { vm.saveWarningText(text); Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show() })
            BigButton("Reset to default", { text = DEFAULT_WARNING_TEXT; vm.saveWarningText(DEFAULT_WARNING_TEXT) }, outlined = true)
        }
        FgCard {
            Heading("Warning image")
            Muted("Shown large on the warning screen. A private, resized copy is kept inside the app.")
            if (image != null) {
                Image(
                    bitmap = image.asImageBitmap(), contentDescription = "Current warning image",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(20.dp)),
                )
            }
            BigButton("Choose image", { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) })
            if (image != null) BigButton("Remove image", { vm.clearWarningImage() }, outlined = true)
        }
        FgCard {
            Heading("Theme")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                THEME_CHOICES.forEach { t ->
                    FilterChip(selected = s.theme == t, onClick = { vm.setTheme(t) }, label = { Text(t) })
                }
            }
        }
        BigButton("Preview warning screen", onPreview, outlined = true)
    }
}
