package com.freedomguard.app.permissions

import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import com.freedomguard.app.receivers.AdminReceiver
import com.freedomguard.app.services.GuardAccessibilityService

data class PermissionStatus(
    val accessibility: Boolean = false,
    val deviceAdmin: Boolean = false,
    val usageAccess: Boolean = false,
    val notifications: Boolean = false,
    val batteryUnrestricted: Boolean = false,
) {
    val grantedCount get() = listOf(accessibility, deviceAdmin, usageAccess, notifications, batteryUnrestricted).count { it }
    val totalCount get() = 5
}

class PermissionChecker(private val ctx: Context) {
    fun read() = PermissionStatus(
        accessibility = isAccessibilityEnabled(),
        deviceAdmin = isAdminActive(),
        usageAccess = hasUsageAccess(),
        notifications = NotificationManagerCompat.from(ctx).areNotificationsEnabled(),
        batteryUnrestricted = ctx.getSystemService(PowerManager::class.java)
            ?.isIgnoringBatteryOptimizations(ctx.packageName) == true,
    )

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(ctx, GuardAccessibilityService::class.java)
        return enabled.split(':').mapNotNull { ComponentName.unflattenFromString(it) }.any { it == me }
    }

    private fun isAdminActive(): Boolean {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java) ?: return false
        return dpm.isAdminActive(ComponentName(ctx, AdminReceiver::class.java))
    }

    @Suppress("DEPRECATION")
    private fun hasUsageAccess(): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java) ?: return false
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}

object SettingsIntents {
    fun appDetails(ctx: Context) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))

    fun accessibility() = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
    fun usageAccess() = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
    fun battery() = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)

    fun deviceAdmin(ctx: Context) = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(ctx, AdminReceiver::class.java))
        putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Makes Android refuse to uninstall Freedom Guard until you deactivate this admin (which requires your PIN). " +
                "Freedom Guard requests no other device-admin powers.",
        )
    }
}

fun Context.safeStart(intent: Intent) {
    try {
        startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(this, "Could not open that settings screen on this phone.", Toast.LENGTH_LONG).show()
    }
}
