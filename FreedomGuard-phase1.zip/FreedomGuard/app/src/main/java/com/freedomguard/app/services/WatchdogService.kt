package com.freedomguard.app.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.freedomguard.app.FreedomGuardApp
import com.freedomguard.app.data.EventKind
import com.freedomguard.app.data.ProtectionEvent
import com.freedomguard.app.domain.KnownBrowsers
import com.freedomguard.app.monitoring.ForegroundAppResolver
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/**
 * Foreground "watchdog". It does NOT block anything itself; it checks every 15 s that the
 * accessibility service and device admin are still on, updates the status notification, and
 * raises an alert if protection was switched off. Foreground type: specialUse (Android 14).
 */
class WatchdogService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifications.ensureChannels(this)
        startForeground(Notifications.ID_STATUS, Notifications.status(this, "Starting…"))
        if (job?.isActive != true) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        val app = FreedomGuardApp.from(this)
        val resolver = ForegroundAppResolver(this)
        var alerted = false
        var lastUnprotectedLog = 0L
        while (currentCoroutineContext().isActive) {
            val s = app.settings.flow.first()
            if (!s.protectionEnabled) {
                Notifications.updateStatus(this, "Protection is paused")
            } else {
                val p = app.permissions.read()
                val text = when {
                    !p.accessibility -> "ATTENTION: Accessibility is off. Private browsing is NOT being blocked."
                    !p.deviceAdmin -> "Protection on. Uninstall protection (device admin) is off."
                    else -> "Protection active"
                }
                Notifications.updateStatus(this, text)
                if (!p.accessibility) {
                    if (!alerted) {
                        alerted = true
                        Notifications.alert(this, "Freedom Guard is not protecting you", "Turn the Freedom Guard accessibility service back on.")
                        app.events.append(ProtectionEvent(System.currentTimeMillis(), EventKind.PROTECTION_OFF, "", "Accessibility service was off"))
                    }
                    val fg = if (p.usageAccess) resolver.currentPackage() else null
                    val now = System.currentTimeMillis()
                    if (fg != null && KnownBrowsers.byPackage(fg) != null && now - lastUnprotectedLog > 10 * 60_000L) {
                        lastUnprotectedLog = now
                        app.events.append(ProtectionEvent(now, EventKind.UNPROTECTED_BROWSER, KnownBrowsers.byPackage(fg)!!.name, "Browser in use while protection was off"))
                    }
                } else {
                    alerted = false
                }
            }
            delay(15_000)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        /** Call only when the app is visible or from a BOOT_COMPLETED receiver (Android 14 rules). */
        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, WatchdogService::class.java))
            } catch (e: Exception) {
                // Not allowed right now (e.g. background start restriction). Safe to ignore:
                // the accessibility service keeps protecting on its own.
            }
        }
    }
}
