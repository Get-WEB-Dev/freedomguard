package com.freedomguard.app.ui

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.freedomguard.app.FreedomGuardApp
import com.freedomguard.app.data.EventKind
import com.freedomguard.app.data.ProtectionEvent
import com.freedomguard.app.data.SettingsKeys
import com.freedomguard.app.data.WarningImageStore
import com.freedomguard.app.domain.DEFAULT_WARNING_TEXT
import com.freedomguard.app.domain.KnownBrowsers
import com.freedomguard.app.domain.Learning
import com.freedomguard.app.monitoring.CaptureController
import com.freedomguard.app.domain.PinRules
import com.freedomguard.app.monitoring.BrowserDetector
import com.freedomguard.app.receivers.AdminReceiver
import com.freedomguard.app.security.PinResult
import com.freedomguard.app.services.WatchdogService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as FreedomGuardApp
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var unlockedUntil = 0L

    private class Snapshot(
        val perms: com.freedomguard.app.permissions.PermissionStatus,
        val browsers: List<com.freedomguard.app.monitoring.InstalledBrowser>,
        val unsupported: List<String>,
        val events: List<ProtectionEvent>,
        val hasPin: Boolean,
    )

    init {
        viewModelScope.launch { app.settings.flow.collect { s -> _state.update { it.copy(settings = s) } } }
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            val snap = withContext(Dispatchers.IO) {
                val det = BrowserDetector(app.packageManager, app.packageName)
                Snapshot(app.permissions.read(), det.scan(), det.unsupportedBrowsers(), app.events.readAll(), app.pin.hasPin())
            }
            _state.update {
                it.copy(
                    permissions = snap.perms, browsers = snap.browsers, unsupportedBrowsers = snap.unsupported,
                    events = snap.events, hasPin = snap.hasPin,
                )
            }
        }
    }

    // ---- PIN session ------------------------------------------------------------------------

    fun isUnlocked(): Boolean = !_state.value.hasPin || SystemClock.elapsedRealtime() < unlockedUntil
    fun lockSession() { unlockedUntil = 0L }

    /** Verifies the PIN, then runs [action]. [done] receives an error message or null. */
    private fun withPin(pin: String, done: (String?) -> Unit, action: suspend () -> String?) {
        viewModelScope.launch {
            val error: String? = when (val r = app.pin.verify(pin)) {
                is PinResult.Ok, is PinResult.NoPin -> action()
                is PinResult.Wrong -> "Wrong PIN. ${r.attemptsLeft} attempts left before a lockout."
                is PinResult.LockedOut -> "Too many attempts. Try again in ${((r.untilMillis - System.currentTimeMillis()) / 1000).coerceAtLeast(1)} s."
            }
            refresh()
            done(error)
        }
    }

    fun unlock(pin: String, done: (String?) -> Unit) = withPin(pin, done) {
        unlockedUntil = SystemClock.elapsedRealtime() + 5 * 60_000L
        null
    }

    fun setInitialPin(pin: String, confirm: String, done: (String?) -> Unit) {
        viewModelScope.launch {
            val err = when {
                app.pin.hasPin() -> "A PIN already exists."
                pin != confirm -> "The two PINs do not match."
                !PinRules.isValid(pin) -> PinRules.MESSAGE
                else -> { app.pin.setPin(pin); null }
            }
            refresh()
            done(err)
        }
    }

    fun changePin(old: String, new: String, confirm: String, done: (String?) -> Unit) {
        when {
            new != confirm -> done("The two new PINs do not match.")
            !PinRules.isValid(new) -> done(PinRules.MESSAGE)
            else -> withPin(old, done) { app.pin.setPin(new); null }
        }
    }

    // ---- protection controls (always re-check the PIN) --------------------------------------

    private fun removalWindowOpen() = System.currentTimeMillis() < _state.value.settings.removalOpenUntil

    fun enableProtection() {
        viewModelScope.launch {
            app.settings.edit { it[SettingsKeys.protection] = true; it[SettingsKeys.openUntil] = 0L }
            WatchdogService.start(app)
        }
    }

    fun disableProtection(pin: String, done: (String?) -> Unit) = withPin(pin, done) {
        val s = _state.value.settings
        if (s.removalDelayHours > 0 && !removalWindowOpen()) {
            "A removal delay is active. Use “Request removal” instead."
        } else {
            app.settings.edit { it[SettingsKeys.protection] = false }
            log(EventKind.PROTECTION_OFF, "", "Turned off in the app with PIN")
            null
        }
    }

    fun setLogOnly(pin: String, value: Boolean, done: (String?) -> Unit) = withPin(pin, done) {
        app.settings.edit { it[SettingsKeys.logOnly] = value }
        null
    }

    fun setRemovalDelay(pin: String, hours: Int, done: (String?) -> Unit) = withPin(pin, done) {
        val cur = _state.value.settings.removalDelayHours
        if (hours < cur && !removalWindowOpen()) {
            "Lowering the delay requires a completed removal request first."
        } else {
            app.settings.edit { it[SettingsKeys.delay] = hours }
            null
        }
    }

    fun requestRemoval(pin: String, done: (String?) -> Unit) = withPin(pin, done) {
        val s = _state.value.settings
        if (s.removalDelayHours == 0) {
            prepareRemovalNow()
        } else {
            app.settings.edit { it[SettingsKeys.requestedAt] = System.currentTimeMillis() }
            log(EventKind.REMOVAL, "", "Removal requested (${s.removalDelayHours} h delay)")
            null
        }
    }

    fun cancelRemoval(pin: String, done: (String?) -> Unit) = withPin(pin, done) {
        app.settings.edit { it[SettingsKeys.requestedAt] = 0L }
        null
    }

    fun prepareRemoval(pin: String, done: (String?) -> Unit) = withPin(pin, done) {
        val s = _state.value.settings
        val ready = s.removalDelayHours == 0 ||
            (s.removalRequestedAt > 0 && System.currentTimeMillis() >= s.removalRequestedAt + s.removalDelayHours * 3_600_000L)
        if (!ready) "The removal delay has not finished yet." else prepareRemovalNow()
    }

    private suspend fun prepareRemovalNow(): String? {
        app.settings.edit {
            it[SettingsKeys.protection] = false
            it[SettingsKeys.requestedAt] = 0L
            it[SettingsKeys.openUntil] = System.currentTimeMillis() + 30 * 60_000L
        }
        val dpm = app.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(app, AdminReceiver::class.java)
        if (dpm != null && dpm.isAdminActive(admin)) dpm.removeActiveAdmin(admin)
        log(EventKind.REMOVAL, "", "Removal window opened for 30 minutes; protection off")
        return null
    }

    // ---- setup, browsers, customization -----------------------------------------------------

    fun finishSetup() {
        viewModelScope.launch {
            app.settings.edit { it[SettingsKeys.setupDone] = true; it[SettingsKeys.protection] = true }
            WatchdogService.start(app)
        }
    }

    fun setMonitored(pkg: String, on: Boolean) {
        viewModelScope.launch {
            app.settings.edit {
                val cur = it[SettingsKeys.monitored] ?: KnownBrowsers.all.map { b -> b.packageName }.toSet()
                it[SettingsKeys.monitored] = if (on) cur + pkg else cur - pkg
            }
        }
    }

    fun setVerified(pkg: String, on: Boolean) {
        viewModelScope.launch {
            app.settings.edit {
                val cur = it[SettingsKeys.verified] ?: emptySet()
                it[SettingsKeys.verified] = if (on) cur + pkg else cur - pkg
            }
        }
    }

    fun saveWarningText(text: String) {
        viewModelScope.launch { app.settings.edit { it[SettingsKeys.text] = text.ifBlank { DEFAULT_WARNING_TEXT } } }
    }

    fun setTheme(name: String) {
        viewModelScope.launch { app.settings.edit { it[SettingsKeys.theme] = name } }
    }

    fun setWarningImage(uri: Uri, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { WarningImageStore.save(app, uri) }
            if (ok) app.settings.edit { it[SettingsKeys.imageVersion] = System.currentTimeMillis() }
            done(ok)
        }
    }

    fun clearWarningImage() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { WarningImageStore.clear(app) }
            app.settings.edit { it[SettingsKeys.imageVersion] = 0L }
        }
    }

    // ---- Teach mode ---------------------------------------------------------------------------

    fun startCapture(pkg: String, kind: String) = CaptureController.start(pkg, kind)

    /** Returns an error message, or null if learning started. */
    fun learnFrom(pkg: String): String? {
        val normal = CaptureController.result(pkg, "normal")
        val priv = CaptureController.result(pkg, "private")
        if (normal.isNullOrEmpty() || priv.isNullOrEmpty()) return "Capture both a normal page and a private page first."
        val diff = Learning.diff(priv, normal)
        if (diff.isEmpty()) return "No difference found. Make sure the second capture was on a PRIVATE page."
        viewModelScope.launch {
            app.settings.edit {
                val cur = it[SettingsKeys.learned] ?: emptySet()
                val prefix = pkg + Learning.SEP
                it[SettingsKeys.learned] = cur.filterNot { e -> e.startsWith(prefix) }.toSet() + diff.map { s -> Learning.encode(pkg, s) }
            }
        }
        return null
    }

    fun clearLearned(pkg: String) {
        viewModelScope.launch {
            app.settings.edit {
                val prefix = pkg + Learning.SEP
                it[SettingsKeys.learned] = (it[SettingsKeys.learned] ?: emptySet()).filterNot { e -> e.startsWith(prefix) }.toSet()
            }
        }
    }

    fun clearLog() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { app.events.clear() }
            refresh()
        }
    }

    private suspend fun log(kind: String, browser: String, detail: String) {
        withContext(Dispatchers.IO) { app.events.append(ProtectionEvent(System.currentTimeMillis(), kind, browser, detail)) }
    }
}
