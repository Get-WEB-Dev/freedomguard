package com.freedomguard.app.services

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.freedomguard.app.R

/**
 * Full-screen overlays drawn with TYPE_ACCESSIBILITY_OVERLAY. This window type is available to an
 * enabled accessibility service without the "draw over other apps" permission and is not subject
 * to Android 14's background-activity-launch limits, because no activity is launched.
 * Built with plain Views so it works from a Service context (no Compose lifecycle needed).
 */
class OverlayController(private val service: AccessibilityService) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private var current: View? = null
    val isShowing: Boolean get() = current != null

    private val navy = Color.parseColor("#0A1330")
    private val blue = Color.parseColor("#3B82F6")
    private val muted = Color.parseColor("#94A3B8")

    private fun dp(v: Int) = (v * service.resources.displayMetrics.density).toInt()

    fun dismiss() {
        current?.let { v -> try { wm.removeView(v) } catch (e: Exception) { /* already gone */ } }
        current = null
    }

    private fun attach(view: View) {
        dismiss()
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(view, lp)
        current = view
    }

    private fun text(msg: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(service).apply {
        text = msg
        textSize = sp
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) }
    }

    private fun button(label: String, filled: Boolean, onClick: () -> Unit) = Button(service).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            if (filled) setColor(blue) else { setColor(Color.TRANSPARENT); setStroke(dp(2), blue) }
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(12) }
        setOnClickListener { onClick() }
    }

    private fun page(content: LinearLayout.() -> Unit): ScrollView {
        val col = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(56), dp(24), dp(40))
            content()
        }
        return ScrollView(service).apply {
            setBackgroundColor(navy)
            isFillViewport = true
            addView(col)
        }
    }

    private fun shield(sizeDp: Int) = ImageView(service).apply {
        setImageResource(R.drawable.ic_shield_warning)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    /** The warning shown when private browsing is detected. Both buttons end on the home screen. */
    fun showWarning(message: String, image: Bitmap?, onDone: () -> Unit) {
        attach(
            page {
                addView(shield(120))
                if (image != null) {
                    addView(
                        ImageView(service).apply {
                            setImageBitmap(image)
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            adjustViewBounds = true
                            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280))
                                .apply { topMargin = dp(16) }
                        },
                    )
                }
                addView(text(message, 22f, bold = true))
                addView(button("I understand", true) { dismiss(); onDone() })
                addView(button("Return to home screen", false) { dismiss(); onDone() })
            },
        )
    }

    /** Locked notice with a single way out (used when a removal delay is active). */
    fun showLocked(title: String, body: String, onHome: () -> Unit) {
        attach(
            page {
                addView(shield(100))
                addView(text(title, 22f, bold = true))
                addView(text(body, 16f, muted))
                addView(button("Return to home screen", true) { dismiss(); onHome() })
            },
        )
    }

    /** Numeric keypad. [verify] must call its callback with null on success or an error message. */
    fun showPinGate(verify: (String, (String?) -> Unit) -> Unit, onSuccess: () -> Unit, onCancel: () -> Unit) {
        val pin = StringBuilder()
        var busy = false
        val dots = text(" ", 28f)
        val error = text("", 14f, Color.parseColor("#EF4444"))
        fun refresh() {
            dots.text = if (pin.isEmpty()) " " else pin.map { "●" }.joinToString(" ")
        }

        fun key(label: String, onClick: () -> Unit) = Button(service).apply {
            text = label
            isAllCaps = false
            textSize = 22f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor("#1A2858")) }
            layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            setOnClickListener { onClick() }
        }

        fun row(vararg keys: View) = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            keys.forEach { addView(it) }
        }

        fun digit(d: String) = key(d) { if (!busy && pin.length < 8) { pin.append(d); error.text = ""; refresh() } }

        attach(
            page {
                addView(shield(90))
                addView(text("Freedom Guard is locked", 22f, bold = true))
                addView(text("Enter your PIN to open this setting.", 15f, muted))
                addView(dots)
                addView(error)
                addView(row(digit("1"), digit("2"), digit("3")))
                addView(row(digit("4"), digit("5"), digit("6")))
                addView(row(digit("7"), digit("8"), digit("9")))
                addView(
                    row(
                        key("⌫") { if (!busy && pin.isNotEmpty()) { pin.deleteCharAt(pin.length - 1); refresh() } },
                        digit("0"),
                        key("OK") {
                            if (!busy && pin.length >= 4) {
                                busy = true
                                verify(pin.toString()) { err ->
                                    busy = false
                                    if (err == null) {
                                        dismiss(); onSuccess()
                                    } else {
                                        error.text = err; pin.clear(); refresh()
                                    }
                                }
                            }
                        },
                    ),
                )
                addView(button("Cancel and go home", false) { dismiss(); onCancel() })
            },
        )
    }
}
