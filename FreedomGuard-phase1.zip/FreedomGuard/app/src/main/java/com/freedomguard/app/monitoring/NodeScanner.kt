package com.freedomguard.app.monitoring

import android.view.accessibility.AccessibilityNodeInfo
import com.freedomguard.app.domain.BrowserDef
import com.freedomguard.app.domain.PrivateModeMatcher

/**
 * Walks the visible UI labels. Privacy rules enforced here:
 *  - web page content (WebView subtrees) is never read;
 *  - editable fields (URL bar, search, passwords) are never read;
 *  - long texts (likely content) are ignored;
 *  - nothing read is stored; callers only receive short labels for in-memory matching.
 */
object NodeScanner {
    private const val MAX_NODES = 800
    private const val MAX_LABEL = 120

    /** Returns true if [onLabel] asked to stop early. */
    fun scan(root: AccessibilityNodeInfo, maxNodes: Int = MAX_NODES, requireVisible: Boolean = true, onLabel: (String) -> Boolean): Boolean {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < maxNodes) {
            val node = stack.removeLast()
            visited++
            if (node.className?.toString() == "android.webkit.WebView") continue
            if (!node.isEditable && (!requireVisible || node.isVisibleToUser)) {
                val t = node.text?.toString()
                if (!t.isNullOrBlank() && t.length <= MAX_LABEL && onLabel(t)) return true
                val d = node.contentDescription?.toString()
                if (!d.isNullOrBlank() && d.length <= MAX_LABEL && onLabel(d)) return true
            }
            for (i in node.childCount - 1 downTo 0) {
                node.getChild(i)?.let { stack.addLast(it) }
            }
        }
        return false
    }

    /** Fingerprints of the visible UI chrome: view ids and short labels. Web content and text fields are skipped. */
    fun signatures(root: AccessibilityNodeInfo): Set<String> {
        val out = HashSet<String>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val node = stack.removeLast()
            visited++
            if (node.className?.toString() == "android.webkit.WebView") continue
            if (node.isVisibleToUser) {
                val editable = node.isEditable
                out.addAll(
                    com.freedomguard.app.domain.Learning.signatures(
                        node.viewIdResourceName,
                        if (editable) null else node.text?.toString(),
                        if (editable) null else node.contentDescription?.toString(),
                    ),
                )
            }
            for (i in node.childCount - 1 downTo 0) node.getChild(i)?.let { stack.addLast(it) }
        }
        return out
    }
}

object PrivateModeScanner {
    /** Returns the matched marker phrase, or null. */
    fun find(browser: BrowserDef, root: AccessibilityNodeInfo): String? {
        var found: String? = null
        NodeScanner.scan(root) { label ->
            found = PrivateModeMatcher.matchInside(browser, label)
            found != null
        }
        return found
    }
}
