package com.freedomguard.app.ui

import com.freedomguard.app.data.ProtectionEvent
import com.freedomguard.app.data.SettingsData
import com.freedomguard.app.monitoring.InstalledBrowser
import com.freedomguard.app.permissions.PermissionStatus

data class UiState(
    val settings: SettingsData = SettingsData(),
    val permissions: PermissionStatus = PermissionStatus(),
    val browsers: List<InstalledBrowser> = emptyList(),
    val unsupportedBrowsers: List<String> = emptyList(),
    val events: List<ProtectionEvent> = emptyList(),
    val hasPin: Boolean = false,
) {
    val monitoredInstalled: Int
        get() = browsers.count { it.installed && it.def.packageName in settings.monitoredBrowsers }
    val installedCount: Int get() = browsers.count { it.installed }
}

enum class Level { OK, WARN, BAD }

data class Health(val level: Level, val title: String, val detail: String)

fun healthOf(state: UiState): Health {
    val s = state.settings
    val p = state.permissions
    return when {
        !s.setupDone -> Health(Level.WARN, "Setup not finished", "Finish the setup wizard to start protection.")
        !s.protectionEnabled -> Health(Level.WARN, "Protection paused", "Turn protection back on in Security.")
        !p.accessibility -> Health(Level.BAD, "Protection NOT working", "The accessibility service is off, so private browsing is not being detected.")
        s.logOnly -> Health(Level.WARN, "Test mode", "Private mode is detected and logged, but nothing is blocked.")
        !state.hasPin || !p.deviceAdmin -> Health(
            Level.WARN, "Active, but easy to remove",
            "Private-mode detection is on. Add a PIN and device admin to make the app harder to remove.",
        )
        else -> Health(
            Level.OK, "Protection active",
            "Watching ${state.monitoredInstalled} installed browser(s). Detection is experimental until you verify each browser.",
        )
    }
}
