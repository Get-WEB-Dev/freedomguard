package com.freedomguard.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.lifecycleScope
import com.freedomguard.app.services.WatchdogService
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.navigation.AppNav
import com.freedomguard.app.ui.theme.FreedomGuardTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by vm.state.collectAsState()
            FreedomGuardTheme(state.settings.theme) { AppNav(vm) }
        }
    }

    override fun onStart() {
        super.onStart()
        // The app is visible, so starting the foreground watchdog is allowed on Android 14.
        lifecycleScope.launch {
            val s = FreedomGuardApp.from(this@MainActivity).settings.flow.first()
            if (s.setupDone && s.protectionEnabled) WatchdogService.start(this@MainActivity)
        }
    }

    override fun onStop() {
        vm.lockSession()
        super.onStop()
    }
}
