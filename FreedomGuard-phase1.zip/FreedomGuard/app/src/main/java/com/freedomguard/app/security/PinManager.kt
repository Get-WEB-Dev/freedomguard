package com.freedomguard.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.freedomguard.app.domain.PinRules
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

sealed interface PinResult {
    object Ok : PinResult
    object NoPin : PinResult
    class Wrong(val attemptsLeft: Int) : PinResult
    class LockedOut(val untilMillis: Long) : PinResult
}

/**
 * The PIN is never stored. We store PBKDF2(PIN, random salt), and that blob is additionally
 * encrypted with an AES-256-GCM key that lives in the Android Keystore (non-exportable).
 * Repeated wrong attempts trigger an escalating lockout.
 */
class PinManager(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("fg_secure", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return gen.generateKey()
    }

    private fun hash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun encrypt(plain: ByteArray): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        return Base64.encodeToString(c.iv + c.doFinal(plain), Base64.NO_WRAP)
    }

    private fun decrypt(blob: String): ByteArray? = try {
        val raw = Base64.decode(blob, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        c.doFinal(raw, 12, raw.size - 12)
    } catch (e: Exception) {
        null
    }

    fun hasPin(): Boolean = prefs.contains(KEY_BLOB)

    suspend fun setPin(pin: String): Boolean = withContext(Dispatchers.Default) {
        if (!PinRules.isValid(pin)) return@withContext false
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val blob = encrypt(salt + hash(pin, salt))
        prefs.edit().putString(KEY_BLOB, blob).putInt(KEY_FAILS, 0).putLong(KEY_LOCK, 0L).apply()
        true
    }

    suspend fun verify(pin: String): PinResult = withContext(Dispatchers.Default) {
        val blob = prefs.getString(KEY_BLOB, null) ?: return@withContext PinResult.NoPin
        val now = System.currentTimeMillis()
        val lockUntil = prefs.getLong(KEY_LOCK, 0L)
        if (now < lockUntil) return@withContext PinResult.LockedOut(lockUntil)

        val plain = decrypt(blob) ?: return@withContext PinResult.NoPin // key lost: fail open rather than brick
        val salt = plain.copyOfRange(0, 16)
        val stored = plain.copyOfRange(16, plain.size)
        if (MessageDigest.isEqual(stored, hash(pin, salt))) {
            prefs.edit().putInt(KEY_FAILS, 0).putLong(KEY_LOCK, 0L).apply()
            return@withContext PinResult.Ok
        }
        val fails = prefs.getInt(KEY_FAILS, 0) + 1
        if (fails >= FREE_ATTEMPTS) {
            val steps = (fails - FREE_ATTEMPTS).coerceAtMost(7)
            val lockMs = (30_000L shl steps).coerceAtMost(60 * 60_000L)
            prefs.edit().putInt(KEY_FAILS, fails).putLong(KEY_LOCK, now + lockMs).apply()
            PinResult.LockedOut(now + lockMs)
        } else {
            prefs.edit().putInt(KEY_FAILS, fails).apply()
            PinResult.Wrong(FREE_ATTEMPTS - fails)
        }
    }

    private companion object {
        const val ALIAS = "freedom_guard_pin_key"
        const val KEY_BLOB = "pin_blob"
        const val KEY_FAILS = "pin_fails"
        const val KEY_LOCK = "pin_lock_until"
        const val ITERATIONS = 120_000
        const val FREE_ATTEMPTS = 5
    }
}
