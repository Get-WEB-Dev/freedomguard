package com.freedomguard.app

import android.app.Application
import android.content.Context
import com.freedomguard.app.data.EventLogRepository
import com.freedomguard.app.data.SettingsRepository
import com.freedomguard.app.permissions.PermissionChecker
import com.freedomguard.app.security.PinManager
import com.freedomguard.app.services.Notifications

/** Tiny hand-rolled service locator; avoids a DI framework dependency. */
class FreedomGuardApp : Application() {
    lateinit var settings: SettingsRepository
        private set
    lateinit var events: EventLogRepository
        private set
    lateinit var pin: PinManager
        private set
    lateinit var permissions: PermissionChecker
        private set

    override fun onCreate() {
        super.onCreate()
        settings = SettingsRepository(this)
        events = EventLogRepository(this)
        pin = PinManager(this)
        permissions = PermissionChecker(this)
        Notifications.ensureChannels(this)
    }

    companion object {
        fun from(ctx: Context): FreedomGuardApp = ctx.applicationContext as FreedomGuardApp
    }
}
