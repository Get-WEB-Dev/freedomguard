package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.freedomguard.app.domain.KnownBrowsers
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.*

@Composable
fun BrowserManagementScreen(onBack: () -> Unit) {
    // Phase 1: selection lives in memory only; persistence (DataStore) arrives with Phase 2.
    val selected = remember { mutableStateMapOf<String, Boolean>().apply { KnownBrowsers.all.forEach { put(it.packageName, true) } } }

    FgScreen(title = "Browsers", onBack = onBack) {
        FgCard(accent = Orange500) {
            Text("Honest status", color = Orange500, fontWeight = FontWeight.SemiBold)
            Muted("No browser is protected yet. Whether a browser's private mode can be blocked will be tested per browser in Phase 3 and recorded in the compatibility matrix. 'Detected' will never be shown as 'protected'.")
        }
        KnownBrowsers.all.forEach { b ->
            FgCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(b.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Muted(b.packageName)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusDot(Red500)
                            Text("Private mode: not protected", color = Red500, style = androidx.compose.material3.MaterialTheme.typography.labelMedium)
                        }
                        Muted("Installed: not scanned yet (Phase 2)")
                    }
                    Switch(
                        checked = selected[b.packageName] == true,
                        onCheckedChange = { selected[b.packageName] = it },
                    )
                }
            }
        }
    }
}
