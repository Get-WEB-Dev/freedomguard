package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.freedomguard.app.domain.Learning
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.UiState
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.navigation.Routes
import com.freedomguard.app.ui.theme.*

@Composable
fun BrowserManagementScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit, nav: (String) -> Unit) {
    val s = state.settings
    FgScreen(title = "Browsers", onBack = onBack) {
        FgCard(accent = Orange500) {
            Text("How to read these statuses", color = Orange500, fontWeight = FontWeight.SemiBold)
            Muted("Freedom Guard stops you at the moment you TAP the button that opens private mode (just seeing a menu does nothing), English only, experimental. If you reach a private window another way (for example a launcher shortcut), it is NOT blocked. A browser only shows green after YOU test it on this phone and confirm it was blocked. Open the browser, start a private tab, and check that the warning appears.")
        }

        FgCard(accent = Blue500) {
            Heading("Step 1: Teach Freedom Guard (recommended)")
            Muted("Blocking the tap on “New Incognito tab” is not enough on its own: private tabs can still be reached other ways. Teach mode learns what YOUR browser looks like in private mode, so those private screens are blocked too.")
            BigButton("Teach private mode", { nav(Routes.TEACH) })
        }

        state.browsers.forEach { b ->
            val pkg = b.def.packageName
            val monitored = pkg in s.monitoredBrowsers
            val verified = pkg in s.verifiedBrowsers
            FgCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(b.def.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Muted(if (b.installed) "Installed${b.versionName?.let { " · v$it" } ?: ""}" else "Not installed")
                    }
                    Switch(checked = monitored, onCheckedChange = { vm.setMonitored(pkg, it) }, enabled = b.installed)
                }
                when {
                    !b.installed -> StatusChip("Not installed", TextSecondary)
                    !monitored -> StatusChip("Not monitored: private mode is open", Red500)
                    verified -> StatusChip("Verified on this phone", Green500)
                    else -> StatusChip("Experimental, not verified", Orange500)
                }
                if (b.installed && monitored) {
                    Muted("Blocks when you tap: ${b.def.entryPhrases.joinToString(", ") { "“$it”" }}")
                    Muted(if (Learning.entriesFor(s.learned, pkg).isEmpty()) "Private screens: not taught yet (only the tap on “new private tab” is blocked)." else "Private screens: taught (${Learning.entriesFor(s.learned, pkg).size} fingerprints).")
                    TextButton(onClick = { vm.setVerified(pkg, !verified) }) {
                        Text(if (verified) "Clear verification" else "I tested it: the warning appeared")
                    }
                }
            }
        }

        if (state.unsupportedBrowsers.isNotEmpty()) {
            FgCard(accent = Red500) {
                Text("Not supported, not protected", color = Red500, fontWeight = FontWeight.SemiBold)
                Muted("These browsers are installed and Freedom Guard can't block their private mode: ${state.unsupportedBrowsers.joinToString(", ")}. You can use them to bypass protection. Consider switching off or restricting them yourself in Settings → Apps (Freedom Guard will not remove anything).")
            }
        }

        FgCard {
            Heading("Controlled alternative")
            Muted("The built-in Safe Browser has no private mode at all, so there is nothing to bypass.")
            BigButton("Open Safe Browser", { nav(Routes.SAFE) }, outlined = true)
        }
    }
}
