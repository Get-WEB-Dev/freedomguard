package com.freedomguard.app.monitoring

import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap

/** In-memory "Teach" captures. Nothing here is written to disk; only the learned difference is saved. */
object CaptureController {
    class Capture(val pkg: String, val kind: String, val endAt: Long)

    @Volatile var active: Capture? = null
        private set
    private val results = ConcurrentHashMap<String, MutableSet<String>>()
    private fun key(pkg: String, kind: String) = "$pkg|$kind"

    fun start(pkg: String, kind: String, ms: Long = 20_000L) {
        results[key(pkg, kind)] = ConcurrentHashMap.newKeySet()
        active = Capture(pkg, kind, SystemClock.elapsedRealtime() + ms)
    }

    /** Called by the accessibility service for every scan of a browser window. Returns true if it recorded. */
    fun record(pkg: String, sigs: Collection<String>): Boolean {
        val a = active ?: return false
        if (SystemClock.elapsedRealtime() > a.endAt) { active = null; return false }
        if (a.pkg != pkg) return false
        results[key(a.pkg, a.kind)]?.addAll(sigs)
        return true
    }

    fun secondsLeft(pkg: String, kind: String): Long {
        val a = active ?: return 0
        if (a.pkg != pkg || a.kind != kind) return 0
        return ((a.endAt - SystemClock.elapsedRealtime()) / 1000).coerceAtLeast(0)
    }

    fun result(pkg: String, kind: String): Set<String>? = results[key(pkg, kind)]?.toSet()
}
