package com.freedomguard.app.monitoring

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context

/** Which app is in front, via Usage Access. Reads only package names, never app content. */
class ForegroundAppResolver(private val ctx: Context) {
    @Suppress("DEPRECATION")
    fun currentPackage(windowMs: Long = 15 * 60_000L): String? {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val end = System.currentTimeMillis()
        val events = try {
            usm.queryEvents(end - windowMs, end)
        } catch (e: SecurityException) {
            return null
        }
        val e = UsageEvents.Event()
        var fg: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> fg = e.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (e.packageName == fg) fg = null
            }
        }
        return fg
    }
}
