package com.freedomguard.app.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.freedomguard.app.domain.DEFAULT_WARNING_TEXT
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.*

/** Sends the user to the launcher. Uses a normal user-visible activity start, which is allowed. */
fun goHome(context: Context) {
    val home = Intent(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_HOME)
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(home)
}

@Composable
fun WarningScreen(
    onDismiss: () -> Unit,
    message: String = DEFAULT_WARNING_TEXT,
) {
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy900, Navy700)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Spacer(Modifier.height(16.dp))
        // Phase 4 will let the user replace this with their own image.
        ShieldIllustration(Modifier.size(240.dp), top = Orange500, bottom = Red500)
        Text(
            message,
            color = TextPrimary,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(4.dp))
        BigButton("I understand", onDismiss)
        BigButton("Return to home screen", onClick = { goHome(context) }, outlined = true)
    }
}
