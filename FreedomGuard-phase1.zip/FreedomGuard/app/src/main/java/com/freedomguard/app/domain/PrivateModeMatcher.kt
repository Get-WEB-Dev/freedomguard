package com.freedomguard.app.domain

/** Pure text matching, kept free of Android classes so it can be unit-tested. */
object PrivateModeMatcher {
    private fun norm(label: String) = label.lowercase().replace('\u2019', '\'').trim()

    /** A TAPPED control opens private mode. Returns the matched phrase or null. */
    fun matchEntry(browser: BrowserDef, label: String?): String? {
        if (label.isNullOrBlank()) return null
        val t = norm(label)
        return browser.entryPhrases.firstOrNull { t.contains(it) }
    }

    /** A label seen in an already-open private window. Strict on purpose: equals or starts-with only. */
    fun matchInside(browser: BrowserDef, label: String?): String? {
        if (label.isNullOrBlank()) return null
        val t = norm(label)
        return browser.insideExact.firstOrNull { t == it } ?: browser.insidePrefixes.firstOrNull { t.startsWith(it) }
    }
}

object TamperScreenMatcher {
    const val APP_NAME = "freedom guard"

    private val keywords = listOf(
        "uninstall", "force stop", "deactivate", "device admin", "use freedom guard",
        "stop freedom guard", "turn off", "clear data", "disable",
    )

    /** True when the visible labels mention this app together with a remove/disable control. */
    fun matches(labels: Collection<String>): Boolean {
        val lower = labels.map { it.lowercase() }
        if (lower.none { it.contains(APP_NAME) }) return false
        return lower.any { t -> keywords.any { t.contains(it) } }
    }
}

object PinRules {
    const val MESSAGE = "PIN must be 4 to 8 digits."
    fun isValid(pin: String): Boolean = pin.length in 4..8 && pin.all { it in '0'..'9' }
}
