package com.freedomguard.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.freedomguard.app.permissions.SettingsIntents
import com.freedomguard.app.permissions.safeStart
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.UiState
import com.freedomguard.app.ui.components.*
import com.freedomguard.app.ui.theme.*

@Composable
fun SecuritySettingsScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val gate = rememberPinGate()
    val s = state.settings
    var showPin by remember { mutableStateOf(false) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    val now = System.currentTimeMillis()
    val delayMs = s.removalDelayHours * 3_600_000L
    val requested = s.removalRequestedAt > 0
    val readyAt = s.removalRequestedAt + delayMs
    val windowOpen = now < s.removalOpenUntil

    FgScreen(title = "Security", onBack = onBack) {
        FgCard {
            Heading("PIN")
            Muted(if (state.hasPin) "A PIN is set. It guards these settings and the uninstall / disable screens." else "No PIN yet. Without a PIN the app is trivial to remove.")
            BigButton(if (state.hasPin) "Change PIN" else "Create PIN", { showPin = true }, outlined = state.hasPin)
        }

        FgCard {
            Heading("Protection")
            SwitchRow(
                "Protection on", if (s.removalDelayHours > 0 && !windowOpen) "Locked by the removal delay. Use “Request removal” below." else "Turning it off needs your PIN.",
                checked = s.protectionEnabled, enabled = state.hasPin || !s.protectionEnabled,
            ) { on ->
                if (on) vm.enableProtection()
                else gate.request("Enter PIN to turn protection off") { pin, done -> vm.disableProtection(pin, done) }
            }
            SwitchRow(
                "Test mode (log only)", "Detects and logs private mode but does NOT show the warning. Use it to check detection safely.",
                checked = s.logOnly,
            ) { v -> gate.request("Enter PIN") { pin, done -> vm.setLogOnly(pin, v, done) } }
        }

        FgCard {
            Heading("Uninstall protection (device admin)")
            if (state.permissions.deviceAdmin) {
                StatusChip("Active: Android blocks uninstall", Green500)
                Muted("Deactivating it from Settings first requires passing the PIN lock this app puts over those screens.")
            } else {
                StatusChip("Off: the app can be uninstalled directly", Orange500)
                BigButton("Activate device admin", { ctx.safeStart(SettingsIntents.deviceAdmin(ctx)) })
            }
        }

        FgCard {
            Heading("Removal delay")
            Muted("Make removal slow on purpose. With a delay on, the PIN alone is not enough: you must request removal and wait. Lowering the delay later also requires a finished request.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "Off", 1 to "1 h", 24 to "24 h", 72 to "72 h").forEach { (h, label) ->
                    FilterChip(
                        selected = s.removalDelayHours == h,
                        onClick = { gate.request("Enter PIN to change the delay") { pin, done -> vm.setRemovalDelay(pin, h, done) } },
                        label = { Text(label) },
                    )
                }
            }
            when {
                windowOpen -> Muted("Removal window is open until ${formatTime(s.removalOpenUntil)}. Device admin is off and protection is paused.")
                requested && now >= readyAt -> {
                    StatusChip("Delay finished", Green500)
                    BigButton("Prepare removal now", { gate.request("Enter PIN to prepare removal") { pin, done -> vm.prepareRemoval(pin, done) } })
                    BigButton("Cancel request", { gate.request("Enter PIN") { pin, done -> vm.cancelRemoval(pin, done) } }, outlined = true)
                }
                requested -> {
                    StatusChip("Waiting until ${formatTime(readyAt)}", Orange500)
                    BigButton("Cancel request", { gate.request("Enter PIN") { pin, done -> vm.cancelRemoval(pin, done) } }, outlined = true)
                }
                state.hasPin -> BigButton(
                    if (s.removalDelayHours == 0) "Prepare removal" else "Request removal",
                    { gate.request("Enter PIN to continue") { pin, done -> vm.requestRemoval(pin, done) } }, outlined = true,
                )
            }
        }

        FgCard(accent = Orange500) {
            Text("What this app cannot do", color = Orange500, fontWeight = FontWeight.SemiBold)
            Muted("• It cannot make uninstalling impossible. Safe Mode, ADB and a factory reset always work.")
            Muted("• Anyone who can switch off Accessibility without opening the guarded screens (for example via a Settings search shortcut) can disable detection. The watchdog will alert you.")
            Muted("• Samsung battery tools may restrict the watchdog if battery is not set to Unrestricted.")
        }
    }

    PinGateDialog(gate)
    if (showPin) {
        PinSetupDialog(
            askOld = state.hasPin,
            onSubmit = { old, new, confirm, done ->
                if (state.hasPin) vm.changePin(old, new, confirm, done) else vm.setInitialPin(new, confirm, done)
            },
            onClose = { showPin = false },
        )
    }
}
