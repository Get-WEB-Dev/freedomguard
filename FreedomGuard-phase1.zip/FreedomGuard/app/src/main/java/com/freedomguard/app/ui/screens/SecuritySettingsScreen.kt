package com.freedomguard.app.ui.screens

import androidx.compose.runtime.Composable
import com.freedomguard.app.ui.components.*

@Composable
fun SecuritySettingsScreen(onBack: () -> Unit) {
    FgScreen(title = "Security", onBack = onBack) {
        FgCard {
            Heading("PIN protection")
            Muted("A PIN will be required to open settings or turn protection off. It will be stored using Android Keystore-backed encryption.")
            BigButton("Set PIN (Phase 5)", {}, enabled = false)
            BigButton("Change PIN (Phase 5)", {}, enabled = false, outlined = true)
        }
        FgCard {
            Heading("Start after restart")
            Muted("A boot receiver will restore monitoring after the phone restarts (Phase 5).")
        }
        FgCard {
            Heading("What this app cannot do")
            Muted("• It cannot stop you from uninstalling it, force-stopping it or revoking its permissions. A PIN only protects Freedom Guard's own settings.")
            Muted("• If a permission is revoked, the dashboard will turn orange/red and tell you, rather than pretending to protect you.")
        }
        PhaseNotice("No PIN exists yet. Nothing in this screen is functional in Phase 1.")
    }
}
