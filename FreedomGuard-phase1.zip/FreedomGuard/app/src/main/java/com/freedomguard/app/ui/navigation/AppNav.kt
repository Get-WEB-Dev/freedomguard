package com.freedomguard.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.freedomguard.app.ui.screens.*

object Routes {
    const val WELCOME = "welcome"
    const val WIZARD = "wizard"
    const val DASHBOARD = "dashboard"
    const val BROWSERS = "browsers"
    const val WARNING = "warning"
    const val CUSTOMIZE = "customize"
    const val SECURITY = "security"
    const val LOG = "log"
    val all = listOf(WELCOME, WIZARD, DASHBOARD, BROWSERS, WARNING, CUSTOMIZE, SECURITY, LOG)
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val back: () -> Unit = { nav.popBackStack() }

    NavHost(
        navController = nav,
        startDestination = Routes.WELCOME,
        enterTransition = { slideInHorizontally(tween(280)) { it / 5 } + fadeIn(tween(280)) },
        exitTransition = { fadeOut(tween(200)) },
        popEnterTransition = { fadeIn(tween(280)) },
        popExitTransition = { slideOutHorizontally(tween(280)) { it / 5 } + fadeOut(tween(200)) },
    ) {
        composable(Routes.WELCOME) {
            WelcomeScreen(onStart = { nav.navigate(Routes.WIZARD) })
        }
        composable(Routes.WIZARD) {
            PermissionWizardScreen(
                onBack = back,
                onFinish = {
                    nav.navigate(Routes.DASHBOARD) { popUpTo(Routes.WELCOME) { inclusive = true } }
                },
            )
        }
        composable(Routes.DASHBOARD) {
            DashboardScreen(
                onBrowsers = { nav.navigate(Routes.BROWSERS) },
                onCustomize = { nav.navigate(Routes.CUSTOMIZE) },
                onSecurity = { nav.navigate(Routes.SECURITY) },
                onLog = { nav.navigate(Routes.LOG) },
                onWizard = { nav.navigate(Routes.WIZARD) },
                onPreviewWarning = { nav.navigate(Routes.WARNING) },
            )
        }
        composable(Routes.BROWSERS) { BrowserManagementScreen(onBack = back) }
        composable(Routes.WARNING) { WarningScreen(onDismiss = back) }
        composable(Routes.CUSTOMIZE) {
            CustomizationScreen(onBack = back, onPreview = { nav.navigate(Routes.WARNING) })
        }
        composable(Routes.SECURITY) { SecuritySettingsScreen(onBack = back) }
        composable(Routes.LOG) { ActivityLogScreen(onBack = back) }
    }
}
