package com.freedomguard.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.freedomguard.app.data.WarningImageStore
import com.freedomguard.app.ui.MainViewModel
import com.freedomguard.app.ui.screens.*
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

object Routes {
    const val WELCOME = "welcome"
    const val WIZARD = "wizard"
    const val DASHBOARD = "dashboard"
    const val BROWSERS = "browsers"
    const val WARNING = "warning"
    const val CUSTOMIZE = "customize"
    const val SECURITY = "security"
    const val LOG = "log"
    const val SAFE = "safe"
    val all = listOf(WELCOME, WIZARD, DASHBOARD, BROWSERS, WARNING, CUSTOMIZE, SECURITY, LOG, SAFE)
}

@Composable
fun AppNav(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    if (!state.settings.loaded) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
        return
    }
    val nav = rememberNavController()
    val ctx = LocalContext.current
    val back: () -> Unit = { nav.popBackStack() }
    val go: (String) -> Unit = { nav.navigate(it) }
    val start = if (state.settings.setupDone) Routes.DASHBOARD else Routes.WELCOME

    NavHost(
        navController = nav,
        startDestination = start,
        enterTransition = { slideInHorizontally(tween(280)) { it / 5 } + fadeIn(tween(280)) },
        exitTransition = { fadeOut(tween(200)) },
        popEnterTransition = { fadeIn(tween(280)) },
        popExitTransition = { slideOutHorizontally(tween(280)) { it / 5 } + fadeOut(tween(200)) },
    ) {
        composable(Routes.WELCOME) { WelcomeScreen(onStart = { go(Routes.WIZARD) }) }
        composable(Routes.WIZARD) {
            PermissionWizardScreen(vm, state, onBack = back, onFinish = {
                vm.finishSetup()
                if (!nav.popBackStack(Routes.DASHBOARD, false)) {
                    nav.navigate(Routes.DASHBOARD) { popUpTo(Routes.WELCOME) { inclusive = true } }
                }
            })
        }
        composable(Routes.DASHBOARD) { DashboardScreen(vm, state, nav = go) }
        composable(Routes.BROWSERS) { BrowserManagementScreen(vm, state, onBack = back, nav = go) }
        composable(Routes.WARNING) {
            val image = remember(state.settings.imageVersion) { WarningImageStore.load(ctx) }
            WarningScreen(message = state.settings.warningText, image = image, onDismiss = back)
        }
        composable(Routes.CUSTOMIZE) { CustomizationScreen(vm, state, onBack = back, onPreview = { go(Routes.WARNING) }) }
        composable(Routes.SECURITY) { SecuritySettingsScreen(vm, state, onBack = back) }
        composable(Routes.LOG) { ActivityLogScreen(vm, state, onBack = back) }
        composable(Routes.SAFE) { SafeBrowserScreen(onBack = back) }
    }
}
