package com.freedomguard.app.services

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.freedomguard.app.FreedomGuardApp
import com.freedomguard.app.data.EventKind
import com.freedomguard.app.data.ProtectionEvent
import com.freedomguard.app.data.SettingsData
import com.freedomguard.app.data.WarningImageStore
import com.freedomguard.app.domain.BrowserDef
import com.freedomguard.app.domain.KnownBrowsers
import com.freedomguard.app.domain.Learning
import com.freedomguard.app.monitoring.CaptureController
import com.freedomguard.app.domain.PrivateModeMatcher
import com.freedomguard.app.domain.TamperPackages
import com.freedomguard.app.domain.TamperScreenMatcher
import com.freedomguard.app.monitoring.NodeScanner
import com.freedomguard.app.monitoring.PrivateModeScanner
import com.freedomguard.app.security.PinResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * The enforcement engine.
 *  1. In supported browsers: looks for private-mode labels and shows the warning overlay.
 *  2. In Settings / package installer: when the screen is about uninstalling, force-stopping or
 *     deactivating Freedom Guard, puts a PIN lock (or a removal-delay notice) over it.
 * The service is limited by its XML config to specific packages, never reads web content or text fields,
 * and keeps nothing it reads.
 */
class GuardAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var app: FreedomGuardApp
    private lateinit var overlay: OverlayController

    @Volatile private var cfg = SettingsData()
    private var scanScheduled = false
    private var graceUntil = 0L
    private var lastLogKey = ""
    private var lastLogAt = 0L

    private val scanRunnable = Runnable {
        scanScheduled = false
        scanActiveWindow()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        app = FreedomGuardApp.from(this)
        overlay = OverlayController(this)
        scope.launch { app.settings.flow.collect { cfg = it } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        if (!::overlay.isInitialized || overlay.isShowing || pkg == packageName) return
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            handleClick(pkg, e) // act on the tap itself, no debounce
            return
        }
        if (KnownBrowsers.byPackage(pkg) == null && pkg !in TamperPackages.all) return
        if (!scanScheduled) {
            scanScheduled = true
            handler.postDelayed(scanRunnable, 300) // coalesce bursts of UI events
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(scanRunnable)
        if (::overlay.isInitialized) overlay.dismiss()
        scope.cancel()
        super.onDestroy()
    }

    private fun scanActiveWindow() {
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        val browser = KnownBrowsers.byPackage(pkg)
        // "Teach" capture runs regardless of protection state
        if (browser != null && CaptureController.active != null) {
            CaptureController.record(pkg, NodeScanner.signatures(root))
            return
        }
        val c = cfg
        if (!c.loaded || !c.setupDone || !c.protectionEnabled || overlay.isShowing) return
        when {
            browser != null -> if (browser.packageName in c.monitoredBrowsers) checkBrowser(browser, root, c)
            pkg in TamperPackages.all -> checkTamper(root, c)
        }
    }

    /** The user tapped something. If it is a supported browser's "open private mode" control, stop it now. */
    private fun handleClick(pkg: String, e: AccessibilityEvent) {
        val c = cfg
        if (!c.loaded || !c.setupDone || !c.protectionEnabled) return
        val browser = KnownBrowsers.byPackage(pkg) ?: return
        if (browser.packageName !in c.monitoredBrowsers) return
        val labels = ArrayList<String>()
        e.text?.forEach { labels.add(it.toString()) }
        e.contentDescription?.let { labels.add(it.toString()) }
        e.source?.let { src -> NodeScanner.scan(src, maxNodes = 6, requireVisible = false) { labels.add(it); false } } // the tapped control only, never a whole list or menu
        val phrase = labels.firstNotNullOfOrNull { PrivateModeMatcher.matchEntry(browser, it) } ?: return
        log(if (c.logOnly) EventKind.PRIVATE_LOG_ONLY else EventKind.PRIVATE_BLOCKED, browser.name, "Tapped: $phrase")
        if (c.logOnly) return
        overlay.showWarning(c.warningText, WarningImageStore.load(this)) { goHome(); killBrowser(browser.packageName) }
    }

    /**
     * Open private window check. It only uses fingerprints LEARNED on this phone via Teach mode
     * (things that appear in the browser's private screen but not its normal screen). Without learned
     * fingerprints it does nothing, so it cannot cause false alarms in normal browsing.
     */
    private fun checkBrowser(browser: BrowserDef, root: AccessibilityNodeInfo, c: SettingsData) {
        val learned = Learning.entriesFor(c.learned, browser.packageName)
        if (learned.isEmpty()) return
        val present = NodeScanner.signatures(root)
        if (learned.none { it in present }) return
        log(if (c.logOnly) EventKind.PRIVATE_LOG_ONLY else EventKind.PRIVATE_BLOCKED, browser.name, "Learned private-mode fingerprint seen")
        if (c.logOnly) return
        overlay.showWarning(c.warningText, WarningImageStore.load(this)) { goHome(); killBrowser(browser.packageName) }
    }

    /** After going home, end the browser's background process so an in-memory private session is lost (best effort). */
    private fun killBrowser(pkg: String) {
        handler.postDelayed({
            try {
                getSystemService(ActivityManager::class.java).killBackgroundProcesses(pkg)
            } catch (e: Exception) {
                // not allowed or already gone
            }
        }, 900)
    }

    private fun checkTamper(root: AccessibilityNodeInfo, c: SettingsData) {
        if (!app.pin.hasPin()) return
        if (SystemClock.elapsedRealtime() < graceUntil) return
        val labels = ArrayList<String>()
        NodeScanner.scan(root) { labels.add(it); false }
        if (!TamperScreenMatcher.matches(labels)) return

        log(EventKind.TAMPER_GATE, "", "Uninstall/disable screen reached")
        if (c.removalDelayHours > 0) {
            if (System.currentTimeMillis() < c.removalOpenUntil) return // removal window opened from inside the app
            overlay.showLocked(
                "Locked by Freedom Guard",
                "A ${c.removalDelayHours}-hour removal delay is active. To remove the app, open Freedom Guard → Security → Request removal, then wait for the delay to finish.",
            ) { log(EventKind.TAMPER_DENIED, "", "Blocked by removal delay"); goHome() }
        } else {
            overlay.showPinGate(
                verify = { pin, done -> verifyPin(pin, done) },
                onSuccess = {
                    graceUntil = SystemClock.elapsedRealtime() + 3 * 60_000L
                    log(EventKind.TAMPER_PASSED, "", "PIN accepted, 3-minute window")
                },
                onCancel = { log(EventKind.TAMPER_DENIED, "", "Cancelled at PIN prompt"); goHome() },
            )
        }
    }

    private fun verifyPin(pin: String, done: (String?) -> Unit) {
        scope.launch {
            val msg = when (val r = app.pin.verify(pin)) {
                is PinResult.Ok, is PinResult.NoPin -> null
                is PinResult.Wrong -> "Wrong PIN. ${r.attemptsLeft} attempts left."
                is PinResult.LockedOut -> "Too many attempts. Try again in ${((r.untilMillis - System.currentTimeMillis()) / 1000).coerceAtLeast(1)} s."
            }
            done(msg)
        }
    }

    private fun goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun log(kind: String, browser: String, detail: String) {
        val now = System.currentTimeMillis()
        val key = "$kind|$browser"
        if (key == lastLogKey && now - lastLogAt < 30_000) return
        lastLogKey = key
        lastLogAt = now
        scope.launch(Dispatchers.IO) { app.events.append(ProtectionEvent(now, kind, browser, detail)) }
    }
}
