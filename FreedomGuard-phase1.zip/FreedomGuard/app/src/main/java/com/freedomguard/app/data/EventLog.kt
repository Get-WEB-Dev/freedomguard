package com.freedomguard.app.data

import android.content.Context
import org.json.JSONObject
import java.io.File

object EventKind {
    const val PRIVATE_BLOCKED = "PRIVATE_BLOCKED"
    const val PRIVATE_LOG_ONLY = "PRIVATE_LOG_ONLY"
    const val TAMPER_GATE = "TAMPER_GATE"
    const val TAMPER_DENIED = "TAMPER_DENIED"
    const val TAMPER_PASSED = "TAMPER_PASSED"
    const val PROTECTION_OFF = "PROTECTION_OFF"
    const val UNPROTECTED_BROWSER = "UNPROTECTED_BROWSER"
    const val ADMIN_DISABLE_REQUESTED = "ADMIN_DISABLE_REQUESTED"
    const val ADMIN_DISABLED = "ADMIN_DISABLED"
    const val REMOVAL = "REMOVAL"
}

/** Only the minimum is stored: time, event type, browser name, and a short non-sensitive note. */
data class ProtectionEvent(val time: Long, val kind: String, val browser: String, val detail: String)

class EventLogRepository(private val context: Context) {
    private val file get() = File(context.filesDir, "events.jsonl")

    fun append(e: ProtectionEvent) {
        synchronized(this) {
            val o = JSONObject().put("t", e.time).put("k", e.kind).put("b", e.browser).put("d", e.detail)
            file.appendText(o.toString() + "\n")
            if (file.length() > 120_000) {
                val keep = file.readLines().takeLast(300)
                file.writeText(keep.joinToString("\n") + "\n")
            }
        }
    }

    fun readAll(): List<ProtectionEvent> {
        synchronized(this) {
            if (!file.exists()) return emptyList()
            return file.readLines().mapNotNull { line ->
                runCatching {
                    val o = JSONObject(line)
                    ProtectionEvent(o.getLong("t"), o.getString("k"), o.optString("b"), o.optString("d"))
                }.getOrNull()
            }.asReversed()
        }
    }

    fun clear() {
        synchronized(this) { file.delete() }
    }
}
