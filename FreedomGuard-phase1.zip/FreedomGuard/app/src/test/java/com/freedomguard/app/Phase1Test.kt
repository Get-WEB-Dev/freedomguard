package com.freedomguard.app

import com.freedomguard.app.domain.DEFAULT_WARNING_TEXT
import com.freedomguard.app.domain.KnownBrowsers
import com.freedomguard.app.ui.navigation.Routes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Phase1Test {
    @Test fun allEightScreensHaveRoutes() = assertEquals(8, Routes.all.toSet().size)

    @Test fun browserCatalogHasUniquePackages() {
        val pkgs = KnownBrowsers.all.map { it.packageName }
        assertEquals(pkgs.size, pkgs.toSet().size)
        assertTrue("com.android.chrome" in pkgs)
    }

    @Test fun defaultWarningStartsWithStop() = assertTrue(DEFAULT_WARNING_TEXT.startsWith("STOP!"))
}
