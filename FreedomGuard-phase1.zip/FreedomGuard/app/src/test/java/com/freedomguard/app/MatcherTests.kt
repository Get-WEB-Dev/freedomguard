package com.freedomguard.app

import com.freedomguard.app.domain.KnownBrowsers
import com.freedomguard.app.domain.Learning
import com.freedomguard.app.domain.PinRules
import com.freedomguard.app.domain.PrivateModeMatcher
import com.freedomguard.app.domain.TamperScreenMatcher
import com.freedomguard.app.ui.navigation.Routes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PrivateModeMatcherTest {
    private val chrome = KnownBrowsers.byPackage("com.android.chrome")!!
    private val samsung = KnownBrowsers.byPackage("com.sec.android.app.sbrowser")!!
    private val edge = KnownBrowsers.byPackage("com.microsoft.emmx")!!
    private val firefox = KnownBrowsers.byPackage("org.mozilla.firefox")!!

    // tapping the entry control
    @Test fun tapNewIncognitoTabMatches() = assertNotNull(PrivateModeMatcher.matchEntry(chrome, "New Incognito tab"))
    @Test fun tapNewTabDoesNotMatch() = assertNull(PrivateModeMatcher.matchEntry(chrome, "New tab"))
    @Test fun samsungTurnOnSecretModeMatches() = assertNotNull(PrivateModeMatcher.matchEntry(samsung, "Turn on Secret mode"))
    @Test fun edgeNewInPrivateWindowMatches() = assertNotNull(PrivateModeMatcher.matchEntry(edge, "New InPrivate window"))
    @Test fun firefoxNewPrivateTabMatches() = assertNotNull(PrivateModeMatcher.matchEntry(firefox, "Open a new private tab"))

    // strict inside detection: a menu or help text that merely mentions the word must NOT trigger
    @Test fun insideExactLabelMatches() = assertNotNull(PrivateModeMatcher.matchInside(chrome, "Incognito"))
    @Test fun insideCurlyApostropheNtpMatches() = assertNotNull(PrivateModeMatcher.matchInside(chrome, "You\u2019ve gone Incognito"))
    @Test fun menuItemMentioningWordDoesNotTriggerInsideCheck() = assertNull(PrivateModeMatcher.matchInside(chrome, "New Incognito tab"))
    @Test fun settingsSentenceDoesNotTriggerInsideCheck() = assertNull(PrivateModeMatcher.matchInside(chrome, "Incognito tracking protection"))
    @Test fun articleTextDoesNotTriggerInsideCheck() = assertNull(PrivateModeMatcher.matchInside(firefox, "How to use private browsing safely"))

    @Test fun nullAndBlankAreIgnored() {
        assertNull(PrivateModeMatcher.matchEntry(chrome, null))
        assertNull(PrivateModeMatcher.matchInside(chrome, "  "))
    }
    @Test fun phrasesOfOneBrowserDoNotMatchAnother() = assertNull(PrivateModeMatcher.matchEntry(edge, "New Incognito tab"))
}

class TamperScreenMatcherTest {
    @Test fun appInfoPageWithUninstallMatches() =
        assertTrue(TamperScreenMatcher.matches(listOf("App info", "Freedom Guard", "Uninstall", "Force stop")))

    @Test fun deviceAdminPageMatches() =
        assertTrue(TamperScreenMatcher.matches(listOf("Freedom Guard", "Deactivate this device admin app")))

    @Test fun accessibilityServicePageMatches() =
        assertTrue(TamperScreenMatcher.matches(listOf("Freedom Guard", "Use Freedom Guard")))

    @Test fun plainAppListDoesNotMatch() =
        assertFalse(TamperScreenMatcher.matches(listOf("Apps", "Freedom Guard", "Chrome", "Calculator")))

    @Test fun otherAppsUninstallPageDoesNotMatch() =
        assertFalse(TamperScreenMatcher.matches(listOf("Calculator", "Uninstall", "Force stop")))
}

class PinRulesTest {
    @Test fun acceptsFourToEightDigits() {
        assertTrue(PinRules.isValid("1234"))
        assertTrue(PinRules.isValid("12345678"))
    }
    @Test fun rejectsTooShortTooLongAndNonDigits() {
        assertFalse(PinRules.isValid("123"))
        assertFalse(PinRules.isValid("123456789"))
        assertFalse(PinRules.isValid("12a4"))
        assertFalse(PinRules.isValid(""))
    }
}

class CatalogTest {
    @Test fun browserPackagesAreUnique() {
        val pkgs = KnownBrowsers.all.map { it.packageName }
        assertEquals(pkgs.size, pkgs.toSet().size)
    }
    @Test fun everyBrowserHasLowercasePhrases() {
        KnownBrowsers.all.forEach { b ->
            assertTrue(b.entryPhrases.isNotEmpty() && b.insideExact.isNotEmpty())
            assertTrue((b.entryPhrases + b.insideExact + b.insidePrefixes).all { it == it.lowercase() })
        }
    }
    @Test fun routesAreUnique() = assertEquals(Routes.all.size, Routes.all.toSet().size)
}

class LearningTest {
    @Test fun diffKeepsOnlyPrivateOnlyItems() {
        val normal = setOf("id:a/toolbar", "txt:new tab", "id:a/menu")
        val priv = setOf("id:a/toolbar", "id:a/incognito_badge", "txt:you've gone incognito")
        assertEquals(setOf("id:a/incognito_badge", "txt:you've gone incognito"), Learning.diff(priv, normal))
    }
    @Test fun diffDropsLabelsWithDigits() =
        assertEquals(setOf("id:a/x"), Learning.diff(setOf("id:a/x", "txt:2 tabs", "txt:12:30"), emptySet()))
    @Test fun signaturesUseIdAndShortLabelsOnly() {
        assertEquals(listOf("id:a/b", "txt:hello", "txt:desc"), Learning.signatures("a/b", " Hello ", "DESC"))
        assertTrue(Learning.signatures(null, "x".repeat(200), null).isEmpty())
    }
    @Test fun entriesAreScopedPerBrowser() {
        val all = setOf(Learning.encode("p1", "id:x"), Learning.encode("p2", "id:y"))
        assertEquals(setOf("id:x"), Learning.entriesFor(all, "p1"))
    }
}
