# Freedom Guard

Personal self-control app for Android 8+ (built and tested-for target: Samsung Galaxy M13, Android 14).
Kotlin, Jetpack Compose, Material 3, DataStore, Android Keystore. No account, no cloud, no analytics.

## How protection works (and its limits)

| Layer | What it does | Honest limit |
|---|---|---|
| Accessibility service | Intercepts the TAP on "New Incognito tab" / "New private tab" / "Turn on Secret mode" etc. in 6 supported browsers, then covers the screen with your warning | Heuristic, English UI only, can break when a browser updates. It does NOT disable private mode; it covers it and sends you home |
| PIN lock over Settings | When Settings / the package installer shows an uninstall, force-stop, deactivate or accessibility-off screen for Freedom Guard, a PIN pad is drawn over it | Only guards screens the matcher recognises; other routes (Safe Mode, ADB, factory reset) are not covered |
| Device admin | Android refuses to uninstall the app until admin is deactivated | Deactivation is possible once past the PIN lock |
| Removal delay (optional) | PIN alone is not enough: request removal, wait 1 / 24 / 72 h | Does not stop Safe Mode / ADB / reset |
| Watchdog (foreground service) | Every 15 s checks accessibility/admin are on; alerts if protection was switched off | Samsung battery tools can restrict it unless set to Unrestricted |
| Safe Browser | Plain WebView browser with no private mode | Only helps if you actually use it |

Unsupported browsers installed on the phone are listed in red inside the app. Their private mode is NOT blocked.

## Privacy

- The accessibility service is limited in XML to the 6 browsers plus Settings and the package installer.
- It skips web page content (WebView), text fields (URL bar, passwords) and long texts.
- Nothing it reads is stored. The log stores only: time, event type, browser name, short note.
- Only permission that touches the network: INTERNET, used solely by the Safe Browser.
- Backups are disabled.

## Build

GitHub Actions: upload the zip, run the workflow, download `freedomguard-debug-apk`.
Android Studio: File > Open > `FreedomGuard`, let Gradle sync, Build > Build APK(s).
Requires JDK 17, Gradle 8.7 (wrapper properties included), AGP 8.5.2, Kotlin 1.9.24.

## Install on the Galaxy M13

1. Copy `app-debug.apk` to the phone and open it. Allow installs from the app you opened it with.
2. Open Freedom Guard and follow the Setup screen.
3. IMPORTANT on Android 13/14: sideloaded apps can't enable Accessibility until you do
   Settings > Apps > Freedom Guard > ⋮ (top right) > **Allow restricted settings**.
4. Enable Accessibility > Installed apps > Freedom Guard. Create a PIN. Activate device admin.
5. Set battery to Unrestricted (Samsung).

## Removing the app on purpose

Security > Request removal (PIN). If a delay is set, wait for it, then Prepare removal.
This pauses protection, deactivates device admin and opens a 30-minute window, after which you can uninstall normally.
