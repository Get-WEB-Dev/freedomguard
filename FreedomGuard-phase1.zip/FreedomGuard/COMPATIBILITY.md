# Compatibility matrix

Status legend: **Implemented** = detection code exists. **Verified** = confirmed by a human on a real device (must be filled in by you).
Nothing is marked Verified until you test it. "Detection implemented" is NOT "blocked".

| Browser | Package | Blocked when tapped (English) | Detection | Warning overlay | Verified on Galaxy M13 / Android 14 |
|---|---|---|---|---|---|
| Google Chrome | com.android.chrome | new incognito tab | Implemented | Implemented | ☐ not yet tested |
| Samsung Internet | com.sec.android.app.sbrowser | turn on secret mode, new secret tab | Implemented | Implemented | ☐ not yet tested |
| Mozilla Firefox | org.mozilla.firefox | new private tab | Implemented | Implemented | ☐ not yet tested |
| Opera | com.opera.browser | new private tab, private mode | Implemented | Implemented | ☐ not yet tested |
| Microsoft Edge | com.microsoft.emmx | new inprivate tab/window | Implemented | Implemented | ☐ not yet tested |
| Brave | com.brave.browser | new private tab/window | Implemented | Implemented | ☐ not yet tested |
| Any other browser | n/a | n/a | None | None | Not protected |

How it works: the tap on the "open private mode" control is intercepted (viewing a menu does nothing). Open private windows are only LOGGED, never blocked: browsers show some of those labels in normal mode too.
Limits: if you start private mode some way the app doesn't see (e.g. a launcher shortcut), nothing will block it yet. The tab may briefly exist behind the warning.
Use Security > Test mode (log only) to see what triggers before enforcing.
To add a browser: add it to `KnownBrowsers` (Models.kt), to `packageNames` in `res/xml/accessibility_service_config.xml`, and to `<queries>` in the manifest.
