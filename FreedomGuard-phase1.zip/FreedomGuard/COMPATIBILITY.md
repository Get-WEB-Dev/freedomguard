# Compatibility matrix

Status legend: **Implemented** = detection code exists. **Verified** = confirmed by a human on a real device (must be filled in by you).
Nothing is marked Verified until you test it. "Detection implemented" is NOT "blocked".

| Browser | Package | Blocked when tapped (English) | Detection | Warning overlay | Verified on Galaxy M13 / Android 14 |
|---|---|---|---|---|---|
| Google Chrome | com.android.chrome | new incognito tab | Implemented | Implemented | ☐ not yet tested |
| Samsung Internet | com.sec.android.app.sbrowser | turn on secret mode, new secret tab | Implemented | Implemented | ☐ not yet tested |
| Mozilla Firefox | org.mozilla.firefox | new private tab | Implemented | Implemented | ☐ not yet tested |
| Opera | com.opera.browser | new private tab, private mode | Implemented | Implemented | ☐ not yet tested |
| Microsoft Edge | com.microsoft.emmx | new inprivate tab/window | Implemented | Implemented | ☐ not yet tested |
| Brave | com.brave.browser | new private tab/window | Implemented | Implemented | ☐ not yet tested |
| Any other browser | n/a | n/a | None | None | Not protected |

How it works: (1) the tap on the "open private mode" control is intercepted; (2) after you run Teach mode, open private screens are recognised by fingerprints learned on this phone (view ids / short labels that appear in private but not in normal). Without Teach, open private windows are NOT detected. After a block, the app sends you home and asks Android to end the browser's background process (best effort; a browser may restore its tabs).
Teach results are per phone and per browser version: redo Teach after a major browser update.
To add a browser: add it to `KnownBrowsers` (Models.kt), `packageNames` in `res/xml/accessibility_service_config.xml`, and `<queries>` in the manifest.
